package com.example.ui.subjects

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyAgendaEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.ui.theme.*

// =========================================================================
// ABA 0: Disciplinas & Assuntos (Accordion Recolhível com CRUD Integrado)
// =========================================================================

@Composable
fun SubjectsAndTopicsTabContent(
    subjects: List<SubjectEntity>,
    topics: List<TopicEntity>,
    expandedSubjectIds: Set<Long>,
    onToggleExpansion: (Long) -> Unit,
    onOpenAddSubject: () -> Unit,
    onEditSubject: (SubjectEntity) -> Unit,
    onDeleteSubject: (SubjectEntity) -> Unit,
    onAddTopic: (Long, String) -> Unit,
    onEditTopic: (TopicEntity) -> Unit,
    onDeleteTopic: (TopicEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Suas Disciplinas (${subjects.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                FilledIconButton(
                    onClick = onOpenAddSubject,
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = PomodoroRed,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("add_subject_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Adicionar disciplina", modifier = Modifier.size(22.dp))
                }
            }
        }

        if (subjects.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Book, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Nenhuma disciplina cadastrada.", color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(subjects, key = { it.id }) { subject ->
                val subjectTopics = topics.filter { it.subjectId == subject.id }
                val isExpanded = expandedSubjectIds.contains(subject.id)

                ExpandableSubjectCard(
                    subject = subject,
                    topics = subjectTopics,
                    isExpanded = isExpanded,
                    onToggleExpansion = { onToggleExpansion(subject.id) },
                    onEditSubject = { onEditSubject(subject) },
                    onDeleteSubject = { onDeleteSubject(subject) },
                    onAddTopic = { topicName -> onAddTopic(subject.id, topicName) },
                    onEditTopic = onEditTopic,
                    onDeleteTopic = onDeleteTopic
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ExpandableSubjectCard(
    subject: SubjectEntity,
    topics: List<TopicEntity>,
    isExpanded: Boolean,
    onToggleExpansion: () -> Unit,
    onEditSubject: () -> Unit,
    onDeleteSubject: () -> Unit,
    onAddTopic: (String) -> Unit,
    onEditTopic: (TopicEntity) -> Unit,
    onDeleteTopic: (TopicEntity) -> Unit
) {
    val subjectColor = try {
        Color(android.graphics.Color.parseColor(subject.colorHex))
    } catch (_: Exception) {
        PomodoroRed
    }

    var newTopicNameInput by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("subject_card_${subject.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Cabeçalho da Disciplina (Clicável para expandir/recolher)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpansion() }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(subjectColor.copy(alpha = 0.2f))
                        .border(1.5.dp, subjectColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Book,
                        contentDescription = null,
                        tint = subjectColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subject.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${topics.size} assunto${if (topics.size == 1) "" else "s"}",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                IconButton(
                    onClick = onEditSubject,
                    modifier = Modifier.size(34.dp).testTag("edit_subject_${subject.id}")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar", tint = TextMuted, modifier = Modifier.size(16.dp))
                }

                IconButton(
                    onClick = onDeleteSubject,
                    modifier = Modifier.size(34.dp).testTag("delete_subject_${subject.id}")
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Excluir", tint = TextMuted, modifier = Modifier.size(16.dp))
                }

                IconButton(
                    onClick = onToggleExpansion,
                    modifier = Modifier.size(34.dp).testTag("expand_subject_${subject.id}")
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Recolher" else "Expandir",
                        tint = subjectColor
                    )
                }
            }

            // Corpo Recolhível (Accordion com CRUD de Assuntos)
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceDark.copy(alpha = 0.6f))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    HorizontalDivider(color = SurfaceCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Assuntos de ${subject.name}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = subjectColor
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Linha para Adicionar Assunto Rápido
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newTopicNameInput,
                            onValueChange = { newTopicNameInput = it },
                            placeholder = { Text("Novo assunto...", fontSize = 12.sp, color = TextMuted) },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("new_topic_input_${subject.id}"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = subjectColor,
                                unfocusedBorderColor = SurfaceCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = SurfaceDark,
                                unfocusedContainerColor = SurfaceDark
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (newTopicNameInput.isNotBlank()) {
                                    onAddTopic(newTopicNameInput.trim())
                                    newTopicNameInput = ""
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = subjectColor,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("add_topic_btn_${subject.id}")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (topics.isEmpty()) {
                        Text(
                            text = "Nenhum assunto cadastrado ainda. Digite acima para adicionar.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        topics.forEach { topic ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceCard)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("topic_row_${topic.id}"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(subjectColor)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = topic.name,
                                    fontSize = 13.sp,
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                IconButton(
                                    onClick = { onEditTopic(topic) },
                                    modifier = Modifier.size(28.dp).testTag("edit_topic_${topic.id}")
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar", tint = TextMuted, modifier = Modifier.size(14.dp))
                                }

                                IconButton(
                                    onClick = { onDeleteTopic(topic) },
                                    modifier = Modifier.size(28.dp).testTag("delete_topic_${topic.id}")
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Excluir", tint = TextMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// ABA 1: Ciclos de Estudo (Criação, Gestão e Distribuição Proporcional)
// =========================================================================

@Composable
fun StudyCyclesTabContent(
    cycles: List<StudyCycleEntity>,
    cycleItems: List<CycleItemWithSubject>,
    subjects: List<SubjectEntity>,
    onOpenAddCycle: () -> Unit,
    onEditCycle: (StudyCycleEntity) -> Unit,
    onDeleteCycle: (StudyCycleEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Ciclos de Estudos (${cycles.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Rotação contínua de matérias com pesos definidos",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                FilledIconButton(
                    onClick = onOpenAddCycle,
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = PomodoroRed,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("add_cycle_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Adicionar ciclo de estudo", modifier = Modifier.size(22.dp))
                }
            }
        }

        if (cycles.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Loop, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Nenhum ciclo de estudos criado ainda.", color = TextMuted, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Toque em 'Novo Ciclo' para criar seu cronograma por rotação.", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        } else {
            items(cycles, key = { it.id }) { cycle ->
                val itemsForThisCycle = cycleItems.filter { it.cycleId == cycle.id }
                StudyCycleCard(
                    cycle = cycle,
                    items = itemsForThisCycle,
                    onEdit = { onEditCycle(cycle) },
                    onDelete = { onDeleteCycle(cycle) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun StudyCycleCard(
    cycle: StudyCycleEntity,
    items: List<CycleItemWithSubject>,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val totalMinutes = items.sumOf { it.targetMinutes }.coerceAtLeast(1)
    val totalHours = totalMinutes / 60
    val totalRemainingMinutes = totalMinutes % 60
    val durationText = if (totalHours > 0) "${totalHours}h ${if (totalRemainingMinutes > 0) "${totalRemainingMinutes}m" else ""}" else "${totalMinutes}m"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cycle_card_${cycle.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PomodoroRed.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Loop, contentDescription = null, tint = PomodoroRed, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = cycle.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${items.size} matérias • Total: $durationText",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar", tint = TextMuted, modifier = Modifier.size(16.dp))
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Excluir", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
            }

            if (cycle.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = cycle.description, fontSize = 12.sp, color = TextSecondary)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Barra Multi-Cor Proporcional do Ciclo
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(SurfaceDark)
            ) {
                items.forEach { item ->
                    val weight = item.targetMinutes.toFloat() / totalMinutes.toFloat()
                    val color = try {
                        Color(android.graphics.Color.parseColor(item.subjectColorHex))
                    } catch (_: Exception) {
                        PomodoroRed
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(weight.coerceAtLeast(0.01f))
                            .background(color)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Lista de Matérias com Percentual
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items.forEach { item ->
                    val percentage = (item.targetMinutes.toFloat() / totalMinutes.toFloat() * 100).toInt()
                    val color = try {
                        Color(android.graphics.Color.parseColor(item.subjectColorHex))
                    } catch (_: Exception) {
                        PomodoroRed
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = item.subjectName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${item.targetMinutes} min ($percentage%)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = color
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// ABA 2: Agendas de Horários Normais (Quadro Semanal)
// =========================================================================

@Composable
fun SchedulesTabContent(
    agendas: List<StudyAgendaEntity>,
    selectedAgendaId: Long?,
    schedules: List<ScheduleWithSubject>,
    subjects: List<SubjectEntity>,
    onSelectAgenda: (Long) -> Unit,
    onOpenAddAgenda: () -> Unit,
    onEditAgenda: (StudyAgendaEntity) -> Unit,
    onDeleteAgenda: (Long) -> Unit,
    onOpenAddSchedule: (Int) -> Unit,
    onEditSchedule: (ScheduleWithSubject) -> Unit,
    onDeleteSchedule: (ScheduleWithSubject) -> Unit
) {
    val dayNames = listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")
    var selectedDay by remember { mutableIntStateOf(1) } // 1 = Seg ... 7 = Dom

    val activeAgenda = agendas.find { it.id == selectedAgendaId } ?: agendas.firstOrNull()
    val targetAgendaId = activeAgenda?.id ?: 1L

    val daySchedules = remember(schedules, targetAgendaId, selectedDay) {
        schedules.filter {
            (it.agendaId == targetAgendaId || (targetAgendaId == 1L && it.agendaId == 0L)) && it.dayOfWeek == selectedDay
        }.sortedWith(compareBy({ it.startHour }, { it.startMinute }))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Seletor de Agendas (Múltiplas Agendas)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Agendas de Horários",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Crie múltiplas agendas para diferentes rotinas",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    FilledIconButton(
                        onClick = onOpenAddAgenda,
                        shape = CircleShape,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = PomodoroRed,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("add_agenda_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Criar nova agenda", modifier = Modifier.size(20.dp))
                    }
                }

                // Chips de seleção de agendas
                if (agendas.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        agendas.forEach { agenda ->
                            val isSelected = agenda.id == targetAgendaId
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectAgenda(agenda.id) },
                                label = {
                                    Text(
                                        agenda.name,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PomodoroRed,
                                    selectedLabelColor = Color.White,
                                    containerColor = SurfaceDark,
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isSelected) PomodoroRed else SurfaceCardBorder,
                                    enabled = true,
                                    selected = isSelected
                                ),
                                modifier = Modifier.testTag("agenda_chip_${agenda.id}")
                            )
                        }
                    }
                }
            }
        }

        // Card da Agenda Ativa (com opção de editar e excluir)
        if (activeAgenda != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeAgenda.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (activeAgenda.description.isNotBlank()) {
                                Text(
                                    text = activeAgenda.description,
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onEditAgenda(activeAgenda) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Editar nome da agenda",
                                    tint = TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            if (agendas.size > 1) {
                                IconButton(
                                    onClick = { onDeleteAgenda(activeAgenda.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Excluir agenda",
                                        tint = TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Título do dia selecionado + Botão "+" simples para adicionar horário
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Horários — ${dayNames[selectedDay - 1]}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Blocos de estudos programados para este dia",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                FilledIconButton(
                    onClick = { onOpenAddSchedule(selectedDay) },
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = PomodoroRed,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("add_schedule_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Adicionar novo horário", modifier = Modifier.size(20.dp))
                }
            }
        }

        // Seletor de Dia da Semana (Chips Seg-Dom)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                dayNames.forEachIndexed { index, name ->
                    val dayNum = index + 1
                    val isSelected = selectedDay == dayNum
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedDay = dayNum },
                        label = { Text(name, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PomodoroRed,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceDark,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) PomodoroRed else SurfaceCardBorder,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }
        }

        if (daySchedules.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Nenhum horário agendado para este dia.", color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(daySchedules, key = { it.id }) { schedule ->
                ScheduleItemCard(
                    schedule = schedule,
                    onEdit = { onEditSchedule(schedule) },
                    onDelete = { onDeleteSchedule(schedule) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ScheduleItemCard(
    schedule: ScheduleWithSubject,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val subjectColor = try {
        Color(android.graphics.Color.parseColor(schedule.subjectColorHex))
    } catch (_: Exception) {
        PomodoroRed
    }

    val startTime = String.format("%02d:%02d", schedule.startHour, schedule.startMinute)
    val endTime = String.format("%02d:%02d", schedule.endHour, schedule.endMinute)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("schedule_card_${schedule.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = startTime, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "até", fontSize = 10.sp, color = TextMuted)
                Text(text = endTime, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(subjectColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = schedule.subjectName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                if (schedule.topic.isNotBlank()) {
                    Text(text = "Tópico: ${schedule.topic}", fontSize = 12.sp, color = TextSecondary)
                }
                if (schedule.label.isNotBlank()) {
                    Text(text = schedule.label, fontSize = 11.sp, color = TextMuted)
                }
            }

            IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar", tint = TextMuted, modifier = Modifier.size(16.dp))
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Excluir", tint = TextMuted, modifier = Modifier.size(16.dp))
            }
        }
    }
}

