package com.example.ui.pomodoro

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyAgendaEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.repository.ReviewStatus
import com.example.data.repository.TopicReviewItem
import com.example.data.repository.TopicPendingPomodoroItem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.domain.model.PomodoroPhase
import com.example.domain.model.StudyType
import com.example.domain.model.TimerState
import com.example.domain.model.TimerTickState
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BreakGreen
import com.example.ui.theme.LongBreakBlue
import com.example.ui.theme.PomodoroRed
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun PomodoroScreen(
    viewModel: PomodoroViewModel,
    modifier: Modifier = Modifier
) {
    val timerTick by viewModel.timerState.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val topics by viewModel.topics.collectAsStateWithLifecycle()
    val cycles by viewModel.studyCycles.collectAsStateWithLifecycle()
    val cycleItems by viewModel.cycleItems.collectAsStateWithLifecycle()
    val schedules by viewModel.schedules.collectAsStateWithLifecycle()
    val agendas by viewModel.agendas.collectAsStateWithLifecycle()
    val todaySummary by viewModel.todaySummary.collectAsStateWithLifecycle()
    val scheduledReviews by viewModel.scheduledReviews.collectAsStateWithLifecycle()
    val topicsAwaitingPomodoros by viewModel.topicsAwaitingPomodoros.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val phaseColor by animateColorAsState(
        targetValue = when (timerTick.phase) {
            PomodoroPhase.FOCUS -> PomodoroRed
            PomodoroPhase.SHORT_BREAK -> BreakGreen
            PomodoroPhase.LONG_BREAK -> LongBreakBlue
        },
        animationSpec = tween(durationMillis = 400),
        label = "phaseColor"
    )

    val phases = remember { listOf(PomodoroPhase.FOCUS, PomodoroPhase.SHORT_BREAK, PomodoroPhase.LONG_BREAK) }
    val currentPhaseIndex = remember(timerTick.phase) {
        phases.indexOf(timerTick.phase).coerceAtLeast(0)
    }
    val pagerState = rememberPagerState(initialPage = currentPhaseIndex, pageCount = { phases.size })
    val coroutineScope = rememberCoroutineScope()

    // Sincronizar mudança de página por deslize com o ViewModel
    LaunchedEffect(pagerState.currentPage) {
        val pagePhase = phases[pagerState.currentPage]
        if (timerTick.phase != pagePhase) {
            viewModel.selectPhase(pagePhase)
        }
    }

    // Sincronizar mudança externa de fase com o Pager
    LaunchedEffect(timerTick.phase) {
        val targetIndex = phases.indexOf(timerTick.phase)
        if (targetIndex >= 0 && pagerState.currentPage != targetIndex) {
            pagerState.animateScrollToPage(targetIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Barra Superior: Indicador de Bloqueio e Configurações
        val blockState by com.example.service.FocusBlockManager.runtimeState.collectAsState()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (blockState.isFocusActive) PomodoroRed.copy(alpha = 0.15f) else SurfaceCard)
                    .border(
                        1.dp,
                        if (blockState.isFocusActive) PomodoroRed else SurfaceCardBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("pomodoro_block_status_chip")
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Status do Bloqueio",
                    tint = if (blockState.isFocusActive) PomodoroRed else BreakGreen,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = if (blockState.isFocusActive) "Bloqueio ativo" else "Protegido",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (blockState.isFocusActive) PomodoroRed else TextSecondary
                )
            }

            IconButton(
                onClick = { viewModel.toggleSettingsDialog(true) },
                modifier = Modifier.testTag("settings_button").size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Configurar",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Fases do Pomodoro (Alternância por toque nos botões ou deslize da tela)
        Row(
            modifier = Modifier
                .background(SurfaceCard, RoundedCornerShape(20.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            phases.forEachIndexed { index, phase ->
                val isCurrent = timerTick.phase == phase
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isCurrent) phaseColor else Color.Transparent)
                        .clickable {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(index)
                            }
                            viewModel.selectPhase(phase)
                        }
                        .testTag("mode_button_${phase.name.lowercase()}")
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = phase.label,
                        color = if (isCurrent) Color.White else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Card de Metadados da Sessão Ativa
        if (uiState.isSessionConfigured && timerTick.phase == PomodoroPhase.FOCUS) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (timerTick.state != TimerState.RUNNING) {
                            viewModel.openPreSessionDialog()
                        }
                    },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.activeTopic,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val subjectColor = uiState.activeSubject?.colorHex?.let {
                                try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { PomodoroRed }
                            } ?: PomodoroRed

                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(subjectColor)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = uiState.activeSubject?.name ?: "Geral",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "• ",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                                Icon(
                                    imageVector = uiState.activeStudyType.icon,
                                    contentDescription = null,
                                    tint = phaseColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = uiState.activeStudyType.label,
                                    color = phaseColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    if (timerTick.state != TimerState.RUNNING) {
                        IconButton(
                            onClick = { viewModel.openPreSessionDialog() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Editar",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Navegação por Deslize Horizontal entre os Modos (Foco, Pausa Curta, Pausa Longa)
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("pomodoro_phase_pager"),
            verticalAlignment = Alignment.CenterVertically
        ) { page ->
            val pagePhase = phases[page]
            val pageColor = when (pagePhase) {
                PomodoroPhase.FOCUS -> PomodoroRed
                PomodoroPhase.SHORT_BREAK -> BreakGreen
                PomodoroPhase.LONG_BREAK -> LongBreakBlue
            }
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularTimerDisplay(
                    timerTick = timerTick,
                    accentColor = if (pagePhase == timerTick.phase) phaseColor else pageColor
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Campo Único: Meta Diária de Pomodoros com botões [+] e [−]
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("daily_goal_card"),
            shape = RoundedCornerShape(16.dp),
            color = SurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Meta diária",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${todaySummary.completedSessions} de ${uiState.dailyGoal} pomodoros",
                        fontSize = 11.sp,
                        color = if (todaySummary.completedSessions >= uiState.dailyGoal) BreakGreen else TextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.decrementDailyGoal() },
                        shape = CircleShape,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("decrement_daily_goal_button"),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = BackgroundDark,
                            contentColor = TextPrimary
                        ),
                        enabled = uiState.dailyGoal > 1
                    ) {
                        Text("−", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "${uiState.dailyGoal}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = PomodoroRed,
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .testTag("daily_goal_value_text")
                    )

                    FilledTonalButton(
                        onClick = { viewModel.incrementDailyGoal() },
                        shape = CircleShape,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("increment_daily_goal_button"),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = BackgroundDark,
                            contentColor = TextPrimary
                        )
                    ) {
                        Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Botão Principal Play / Pause
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val isRunning = timerTick.state == TimerState.RUNNING
            Button(
                onClick = { viewModel.onPlayOrPauseClicked(context) },
                modifier = Modifier
                    .size(70.dp)
                    .testTag("play_pause_button"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = phaseColor,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isRunning) "Pausar" else "Iniciar",
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        // Ação rápida para contabilizar tempo de pomodoro incompleto
        if (timerTick.phase == PomodoroPhase.FOCUS && timerTick.elapsedSeconds > 0) {
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = { viewModel.requestStopOrReset() },
                modifier = Modifier
                    .testTag("save_incomplete_session_quick_button")
                    .height(38.dp),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFF59E0B)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                val mins = timerTick.elapsedSeconds / 60
                val secs = timerTick.elapsedSeconds % 60
                val timeLabel = if (mins > 0) "${mins}m ${secs}s" else "${secs}s"
                Text(
                    text = "Salvar ($timeLabel)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Resumo do Dia
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = SurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Hoje",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    val hours = todaySummary.totalSeconds / 3600
                    val minutes = (todaySummary.totalSeconds % 3600) / 60
                    Text(
                        text = if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .height(28.dp)
                        .width(1.dp)
                        .background(SurfaceCardBorder)
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Concluídas",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${todaySummary.completedSessions}",
                        color = PomodoroRed,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Banner de aviso de agendamento automático de revisão
        uiState.reviewScheduledBanner?.let { bannerText ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.dismissReviewBanner() },
                color = Color(0xFF10B981).copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = bannerText,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.dismissReviewBanner() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SEÇÃO RECOLHÍVEL DE REVISÕES PERIÓDICAS (Agendadas automaticamente ao completar 2 pomodoros)
        CollapsibleReviewsSection(
            reviews = scheduledReviews,
            topicsAwaitingPomodoros = topicsAwaitingPomodoros,
            isExpanded = uiState.isReviewsSectionExpanded,
            selectedFilter = uiState.selectedReviewFilter,
            onToggleExpanded = { viewModel.toggleReviewsExpanded() },
            onSelectFilter = { viewModel.setReviewFilter(it) },
            onStartReview = { viewModel.startReviewSession(it) },
            onCompleteReview = { viewModel.completeReview(it) },
            onOpenAddReview = { viewModel.openAddReviewDialog() },
            onDeleteReview = { viewModel.deleteReviewTopic(it) },
            onStartFocusPending = { topicName, subId -> viewModel.startFocusForTopic(topicName, subId) }
        )

        Spacer(modifier = Modifier.height(28.dp))
    }

    // Diálogo para Agendar Nova Revisão de Assunto
    if (uiState.showAddReviewDialog) {
        AddReviewDialog(
            subjects = subjects,
            selectedSubjectId = uiState.addReviewSelectedSubjectId,
            topicInput = uiState.addReviewTopicInput,
            markStudiedToday = uiState.addReviewMarkStudiedToday,
            errorMessage = uiState.addReviewError,
            onSubjectSelected = { viewModel.onAddReviewSubjectChange(it) },
            onTopicChange = { viewModel.onAddReviewTopicChange(it) },
            onMarkStudiedChange = { viewModel.onAddReviewMarkStudiedChange(it) },
            onDismiss = { viewModel.closeAddReviewDialog() },
            onConfirm = { viewModel.saveNewReview() }
        )
    }

    // DIÁLOGO DE INÍCIO / PRÉ-SESSÃO DE FOCO (Alternância entre Ciclos, Agendas e Modo Livre)
    if (uiState.showPreSessionDialog) {
        PreSessionSetupDialog(
            studyMode = uiState.studyMode,
            cycles = cycles,
            cycleItems = cycleItems,
            schedules = schedules,
            agendas = agendas,
            selectedCycleId = uiState.selectedCycleId,
            selectedAgendaId = uiState.selectedAgendaId,
            selectedScheduleDayOfWeek = uiState.selectedScheduleDayOfWeek,
            selectedScheduleId = uiState.selectedScheduleId,
            topicInput = uiState.preSessionTopicInput,
            selectedSubject = uiState.preSessionSubjectSelected,
            selectedStudyType = uiState.preSessionStudyType,
            subjects = subjects,
            topics = topics,
            errorMessage = uiState.preSessionError,
            isAutoLinked = uiState.isTopicAutoLinked,
            onModeSelected = { viewModel.setStudyMode(it) },
            onCycleSelected = { viewModel.selectStudyCycle(it) },
            onCycleSubjectSelected = { viewModel.selectSubjectFromCycle(it) },
            onAgendaSelected = { viewModel.selectAgenda(it) },
            onScheduleDaySelected = { viewModel.setScheduleDayOfWeek(it) },
            onScheduleSelected = { viewModel.selectScheduleForStudy(it) },
            onTopicChange = { viewModel.onPreSessionTopicChange(it) },
            onTopicSelectedFromList = { viewModel.selectPreSessionTopicFromList(it) },
            onSubjectSelected = { viewModel.onPreSessionSubjectSelect(it) },
            onStudyTypeSelected = { viewModel.onPreSessionStudyTypeSelect(it) },
            onDismiss = { viewModel.closePreSessionDialog() },
            onConfirm = { viewModel.confirmPreSessionAndStart() }
        )
    }

    // Diálogo de Permissão de Acessibilidade Necessária para o Bloqueador
    if (uiState.showPermissionWarningDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissPermissionWarning(startAnyway = false) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = Color(0xFFF59E0B),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Ativar Bloqueio no Android",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Para que o StudyFocus consiga fechar e bloquear aplicativos selecionados (como YouTube e Facebook) e sites durante o foco, o Android exige que você ative o Serviço de Acessibilidade.",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Toque em 'Ativar nas Configurações' e ligue a chave 'StudyFocus - Bloqueio de Distrações'.",
                        color = Color(0xFFF59E0B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.openAccessibilitySettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("enable_accessibility_confirm_button")
                ) {
                    Text("Ativar nas Configurações", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.dismissPermissionWarning(startAnyway = true) },
                    modifier = Modifier.testTag("start_without_blocking_button")
                ) {
                    Text("Iniciar sem Bloqueio", color = TextSecondary)
                }
            },
            containerColor = SurfaceCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Caixa de diálogo de Conclusão da Sessão
    if (uiState.showCompletionDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissCompletionDialog() },
            title = {
                Text(
                    text = "Sessão Concluída!",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Você completou ${uiState.completedDurationSecs / 60} min de estudo em '${uiState.activeTopic.ifEmpty { "Estudo Geral" }}'!",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = uiState.sessionNotes,
                        onValueChange = { viewModel.updateNotes(it) },
                        label = { Text("Anotações da sessão (opcional)") },
                        placeholder = { Text("Ex: Finalizei exercícios 1 a 10") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("session_notes_input"),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.saveCompletedSession(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = phaseColor),
                    modifier = Modifier.testTag("save_session_button")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Salvar Registro")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissCompletionDialog() }) {
                    Text("Pular Anotação", color = TextSecondary)
                }
            }
        )
    }

    // Diálogo de Configuração de Durações
    if (uiState.showSettingsDialog) {
        TimerSettingsDialog(
            initialFocus = uiState.focusMinutes,
            initialShortBreak = uiState.shortBreakMinutes,
            initialLongBreak = uiState.longBreakMinutes,
            onDismiss = { viewModel.toggleSettingsDialog(false) },
            onConfirm = { f, s, l -> viewModel.setDurations(f, s, l) }
        )
    }

    // Diálogo para Contabilizar Pomodoro Incompleto
    if (uiState.showIncompleteSessionDialog) {
        val elapsedMinutes = uiState.incompleteSessionSecs / 60
        val elapsedSeconds = uiState.incompleteSessionSecs % 60
        val timeFormatted = if (elapsedMinutes > 0) "${elapsedMinutes}m ${elapsedSeconds}s" else "${elapsedSeconds}s"

        AlertDialog(
            onDismissRequest = { viewModel.cancelIncompleteDialog() },
            title = {
                Text(
                    text = "Contabilizar Tempo Incompleto?",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Você estudou $timeFormatted neste ciclo.",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Deseja salvar e contabilizar esse tempo no histórico e estatísticas de estudo?",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = uiState.sessionNotes,
                        onValueChange = { viewModel.updateNotes(it) },
                        label = { Text("Anotações da sessão (opcional)") },
                        placeholder = { Text("Ex: Interrompido para pausa") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("incomplete_notes_input"),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.saveIncompleteSession(uiState.sessionNotes) },
                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                    modifier = Modifier.testTag("save_incomplete_session_button")
                ) {
                    Text("Salvar Tempo")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { viewModel.discardIncompleteSession() }) {
                        Text("Descartar", color = PomodoroRed)
                    }
                    TextButton(onClick = { viewModel.cancelIncompleteDialog() }) {
                        Text("Continuar", color = TextSecondary)
                    }
                }
            }
        )
    }
}

