package com.example.ui.pomodoro

import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import java.util.Locale
import com.example.domain.model.TimerState

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TimerTickState
import com.example.domain.util.TimeFormatter
import com.example.ui.theme.*

@Composable
fun CircularTimerDisplay(
    timerTick: TimerTickState,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = timerTick.progress,
        animationSpec = tween(durationMillis = 500),
        label = "progress"
    )

    val minutes = timerTick.remainingSeconds / 60
    val seconds = timerTick.remainingSeconds % 60
    val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

    Box(
        modifier = modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 12.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val radius = diameter / 2f
            val center = this.center

            drawCircle(
                color = SurfaceCard,
                radius = radius,
                center = center,
                style = Stroke(width = strokeWidth)
            )

            drawArc(
                color = accentColor,
                startAngle = -90f,
                sweepAngle = 360f * animatedProgress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = formattedTime,
                color = TextPrimary,
                fontSize = 46.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = when (timerTick.state) {
                    TimerState.IDLE -> "Pronto"
                    TimerState.RUNNING -> "Foco ativo"
                    TimerState.PAUSED -> "Pausado"
                    TimerState.COMPLETED -> "Concluído"
                },
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun TimerSettingsDialog(
    initialFocus: Int,
    initialShortBreak: Int,
    initialLongBreak: Int,
    onDismiss: () -> Unit,
    onConfirm: (focus: Int, shortBreak: Int, longBreak: Int) -> Unit
) {
    var focusText by remember { mutableStateOf(initialFocus.toString()) }
    var shortBreakText by remember { mutableStateOf(initialShortBreak.toString()) }
    var longBreakText by remember { mutableStateOf(initialLongBreak.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Durações", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tempo de Foco
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = focusText,
                        onValueChange = { focusText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Foco", fontSize = 12.sp) },
                        placeholder = { Text("25", fontSize = 12.sp) },
                        suffix = { Text("min", color = TextSecondary, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = null, tint = PomodoroRed, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_focus_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 25, 45, 50, 60).forEach { mins ->
                            val isSelected = focusText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) PomodoroRed.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) PomodoroRed else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { focusText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) PomodoroRed else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Pausa Curta
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = shortBreakText,
                        onValueChange = { shortBreakText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Pausa Curta", fontSize = 12.sp) },
                        placeholder = { Text("5", fontSize = 12.sp) },
                        suffix = { Text("min", color = TextSecondary, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Pause, contentDescription = null, tint = BreakGreen, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_short_break_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(3, 5, 10, 15).forEach { mins ->
                            val isSelected = shortBreakText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) BreakGreen.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) BreakGreen else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { shortBreakText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) BreakGreen else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Pausa Longa
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = longBreakText,
                        onValueChange = { longBreakText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Pausa Longa", fontSize = 12.sp) },
                        placeholder = { Text("15", fontSize = 12.sp) },
                        suffix = { Text("min", color = TextSecondary, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = LongBreakBlue, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_long_break_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(10, 15, 20, 30).forEach { mins ->
                            val isSelected = longBreakText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) LongBreakBlue.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) LongBreakBlue else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { longBreakText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) LongBreakBlue else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val focus = focusText.toIntOrNull()?.coerceIn(1, 180) ?: initialFocus
                    val shortBreak = shortBreakText.toIntOrNull()?.coerceIn(1, 60) ?: initialShortBreak
                    val longBreak = longBreakText.toIntOrNull()?.coerceIn(1, 90) ?: initialLongBreak
                    onConfirm(focus, shortBreak, longBreak)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                modifier = Modifier.testTag("save_settings_button")
            ) {
                Text("Aplicar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}

