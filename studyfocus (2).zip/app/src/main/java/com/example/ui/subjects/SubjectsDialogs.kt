package com.example.ui.subjects

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyAgendaEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.ui.theme.*

// =========================================================================
// Diálogos de Suporte (CRUD Disciplina, Tópico, Ciclo, Agenda)
// =========================================================================

@Composable
fun AddEditSubjectDialog(
    isEditing: Boolean,
    name: String,
    selectedColorHex: String,
    availableColors: List<String>,
    errorMessage: String?,
    onNameChange: (String) -> Unit,
    onColorSelect: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Editar Disciplina" else "Nova Disciplina",
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = onNameChange,
                    label = { Text("Nome da disciplina") },
                    placeholder = { Text("Ex: Física Quântica") },
                    singleLine = true,
                    isError = errorMessage != null,
                    modifier = Modifier.fillMaxWidth().testTag("subject_name_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(text = "Cor da Disciplina", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    availableColors.forEach { colorHex ->
                        val color = Color(android.graphics.Color.parseColor(colorHex))
                        val isSelected = colorHex.equals(selectedColorHex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { onColorSelect(colorHex) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                modifier = Modifier.testTag("save_subject_confirm_btn")
            ) {
                Text("Salvar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun EditTopicDialog(
    name: String,
    errorMessage: String?,
    onNameChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Editar Assunto", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = onNameChange,
                    label = { Text("Nome do assunto") },
                    singleLine = true,
                    isError = errorMessage != null,
                    modifier = Modifier.fillMaxWidth().testTag("edit_topic_name_input"),
                    shape = RoundedCornerShape(10.dp)
                )
                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed)) {
                Text("Salvar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun AddEditCycleDialog(
    isEditing: Boolean,
    name: String,
    description: String,
    draftItems: List<Pair<Long, Int>>,
    availableSubjects: List<SubjectEntity>,
    errorMessage: String?,
    onNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onAddSubject: (Long, Int) -> Unit,
    onRemoveSubject: (Long) -> Unit,
    onUpdateDuration: (Long, Int) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Editar Ciclo de Estudo" else "Novo Ciclo de Estudo",
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().height(380.dp)) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = onNameChange,
                        label = { Text("Nome do ciclo") },
                        placeholder = { Text("Ex: Ciclo ENEM 2026") },
                        singleLine = true,
                        isError = errorMessage != null,
                        modifier = Modifier.fillMaxWidth().testTag("cycle_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = onDescriptionChange,
                        label = { Text("Descrição (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "Matérias no Ciclo (${draftItems.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = "Digite a duração de estudo de cada matéria (em minutos):", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Matérias já no ciclo com ajuste de duração digitando
                items(draftItems) { pair ->
                    val subject = availableSubjects.firstOrNull { it.id == pair.first }
                    if (subject != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val subjectColor = try {
                                    Color(android.graphics.Color.parseColor(subject.colorHex))
                                } catch (_: Exception) {
                                    PomodoroRed
                                }

                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(subjectColor)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = subject.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )

                                // Digitação direta do tempo em minutos
                                var minutesInput by remember(pair.first) { mutableStateOf(pair.second.toString()) }
                                OutlinedTextField(
                                    value = minutesInput,
                                    onValueChange = { input ->
                                        val digits = input.filter { it.isDigit() }
                                        minutesInput = digits
                                        val mins = digits.toIntOrNull() ?: 0
                                        if (mins > 0) {
                                            onUpdateDuration(subject.id, mins)
                                        }
                                    },
                                    label = { Text("Duração", fontSize = 11.sp) },
                                    placeholder = { Text("Ex: 50", fontSize = 11.sp) },
                                    suffix = { Text("min", fontSize = 11.sp, color = TextSecondary) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .width(120.dp)
                                        .testTag("cycle_subject_duration_input_${subject.id}"),
                                    shape = RoundedCornerShape(8.dp)
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                IconButton(
                                    onClick = { onRemoveSubject(subject.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Remover disciplina",
                                        tint = TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "+ Adicionar Disciplina ao Ciclo:", fontSize = 12.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))

                    val unselected = availableSubjects.filter { sub -> draftItems.none { it.first == sub.id } }
                    if (unselected.isEmpty()) {
                        Text(text = "Todas as disciplinas já estão adicionadas.", fontSize = 11.sp, color = TextMuted)
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            unselected.forEach { sub ->
                                OutlinedButton(
                                    onClick = { onAddSubject(sub.id, 60) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("+ ${sub.name}", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed)) {
                Text("Salvar Ciclo")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun AddEditScheduleDialog(
    isEditing: Boolean,
    dayOfWeek: Int,
    startHour: Int,
    startMinute: Int,
    endHour: Int,
    endMinute: Int,
    subjectId: Long?,
    topic: String,
    label: String,
    availableSubjects: List<SubjectEntity>,
    errorMessage: String?,
    onUpdate: (Int, Int, Int, Int, Int, Long?, String, String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    val dayNames = listOf("Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Editar Horário" else "Novo Horário de Estudo",
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                item {
                    Text(text = "Dia da Semana", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dayNames.forEachIndexed { index, name ->
                            val dayNum = index + 1
                            val isSelected = dayOfWeek == dayNum
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    onUpdate(dayNum, startHour, startMinute, endHour, endMinute, subjectId, topic, label)
                                },
                                label = { Text(name, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PomodoroRed,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "Disciplina", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        availableSubjects.forEach { sub ->
                            val isSelected = subjectId == sub.id
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    onUpdate(dayOfWeek, startHour, startMinute, endHour, endMinute, sub.id, topic, label)
                                },
                                label = { Text(sub.name, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PomodoroRed,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "Horário de Início e Término", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = String.format("%02d:%02d", startHour, startMinute),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Início") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = String.format("%02d:%02d", endHour, endMinute),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Término") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Ajustar Hora de Início: ${startHour}h", fontSize = 12.sp, color = TextMuted)
                    Slider(
                        value = startHour.toFloat(),
                        onValueChange = {
                            val newStart = it.toInt()
                            val newEnd = if (endHour <= newStart) (newStart + 1).coerceAtMost(23) else endHour
                            onUpdate(dayOfWeek, newStart, startMinute, newEnd, endMinute, subjectId, topic, label)
                        },
                        valueRange = 0f..23f,
                        steps = 22
                    )

                    Text(text = "Ajustar Hora de Término: ${endHour}h", fontSize = 12.sp, color = TextMuted)
                    Slider(
                        value = endHour.toFloat(),
                        onValueChange = {
                            onUpdate(dayOfWeek, startHour, startMinute, it.toInt().coerceAtLeast(startHour + 1), endMinute, subjectId, topic, label)
                        },
                        valueRange = 1f..23f,
                        steps = 21
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = topic,
                        onValueChange = {
                            onUpdate(dayOfWeek, startHour, startMinute, endHour, endMinute, subjectId, it, label)
                        },
                        label = { Text("Assunto / Conteúdo (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = label,
                        onValueChange = {
                            onUpdate(dayOfWeek, startHour, startMinute, endHour, endMinute, subjectId, topic, it)
                        },
                        label = { Text("Rótulo do Bloco (ex: Teoria, Revisão)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed)) {
                Text("Salvar Horário")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun AddEditAgendaDialog(
    isEditing: Boolean,
    name: String,
    description: String,
    errorMessage: String?,
    onNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Editar Agenda" else "Nova Agenda de Horários",
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = onNameChange,
                    label = { Text("Nome da Agenda") },
                    placeholder = { Text("Ex: Semestre 1, Noturno, Concurso") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = onDescriptionChange,
                    label = { Text("Descrição (opcional)") },
                    placeholder = { Text("Ex: Grade semanal para o período letivo") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                if (errorMessage != null) {
                    Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed)) {
                Text(if (isEditing) "Salvar" else "Criar Agenda")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(16.dp)
    )
}
