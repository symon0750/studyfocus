package com.example.ui.subjects

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyAgendaEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BreakGreen
import com.example.ui.theme.PomodoroRed
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SubjectsScreen(
    viewModel: SubjectsViewModel,
    modifier: Modifier = Modifier
) {
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val topics by viewModel.topics.collectAsStateWithLifecycle()
    val cycles by viewModel.studyCycles.collectAsStateWithLifecycle()
    val cycleItems by viewModel.cycleItems.collectAsStateWithLifecycle()
    val schedules by viewModel.schedules.collectAsStateWithLifecycle()
    val agendas by viewModel.agendas.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val tabs = listOf("Disciplinas", "Ciclos", "Agenda")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        // Cabeçalho Principal
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Planner",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        // Abas Superiores
        ScrollableTabRow(
            selectedTabIndex = uiState.selectedTab,
            containerColor = SurfaceDark,
            contentColor = TextPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[uiState.selectedTab]),
                    color = PomodoroRed,
                    height = 2.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                val selected = uiState.selectedTab == index
                Tab(
                    selected = selected,
                    onClick = { viewModel.selectTab(index) },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) PomodoroRed else TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier.testTag("subjects_tab_$index")
                )
            }
        }

        // Conteúdo da Aba Ativa
        Box(modifier = Modifier.fillMaxSize()) {
            when (uiState.selectedTab) {
                0 -> SubjectsAndTopicsTabContent(
                    subjects = subjects,
                    topics = topics,
                    expandedSubjectIds = uiState.expandedSubjectIds,
                    onToggleExpansion = { viewModel.toggleSubjectExpansion(it) },
                    onOpenAddSubject = { viewModel.openAddSubjectDialog() },
                    onEditSubject = { viewModel.openEditSubjectDialog(it) },
                    onDeleteSubject = { viewModel.deleteSubject(it) },
                    onAddTopic = { subjectId, topicName -> viewModel.addTopicToSubject(subjectId, topicName) },
                    onEditTopic = { viewModel.openEditTopicDialog(it) },
                    onDeleteTopic = { viewModel.deleteTopic(it) }
                )
                1 -> StudyCyclesTabContent(
                    cycles = cycles,
                    cycleItems = cycleItems,
                    subjects = subjects,
                    onOpenAddCycle = { viewModel.openAddCycleDialog() },
                    onEditCycle = { viewModel.openEditCycleDialog(it) },
                    onDeleteCycle = { viewModel.deleteCycle(it) }
                )
                2 -> SchedulesTabContent(
                    agendas = agendas,
                    selectedAgendaId = uiState.selectedAgendaId,
                    schedules = schedules,
                    subjects = subjects,
                    onSelectAgenda = { viewModel.selectAgenda(it) },
                    onOpenAddAgenda = { viewModel.openAddAgendaDialog() },
                    onEditAgenda = { viewModel.openEditAgendaDialog(it) },
                    onDeleteAgenda = { viewModel.deleteAgenda(it) },
                    onOpenAddSchedule = { defaultDay -> viewModel.openAddScheduleDialog(defaultDay) },
                    onEditSchedule = { viewModel.openEditScheduleDialog(it) },
                    onDeleteSchedule = { viewModel.deleteSchedule(it.id) }
                )
            }
        }
    }

    // Diálogos de Suporte (CRUD)
    if (uiState.showAddEditSubjectDialog) {
        AddEditSubjectDialog(
            isEditing = uiState.editingSubject != null,
            name = uiState.subjectNameInput,
            selectedColorHex = uiState.selectedColorHex,
            availableColors = viewModel.availableColors,
            errorMessage = uiState.subjectError,
            onNameChange = { viewModel.onSubjectNameChange(it) },
            onColorSelect = { viewModel.onSubjectColorSelect(it) },
            onDismiss = { viewModel.closeSubjectDialog() },
            onSave = { viewModel.saveSubject() }
        )
    }

    if (uiState.showEditTopicDialog) {
        EditTopicDialog(
            name = uiState.topicEditNameInput,
            errorMessage = uiState.topicError,
            onNameChange = { viewModel.onTopicEditNameChange(it) },
            onDismiss = { viewModel.closeEditTopicDialog() },
            onSave = { viewModel.saveTopicEdit() }
        )
    }

    if (uiState.showAddEditCycleDialog) {
        AddEditCycleDialog(
            isEditing = uiState.editingCycle != null,
            name = uiState.cycleNameInput,
            description = uiState.cycleDescriptionInput,
            draftItems = uiState.cycleItemsDraft,
            availableSubjects = subjects,
            errorMessage = uiState.cycleError,
            onNameChange = { viewModel.onCycleNameChange(it) },
            onDescriptionChange = { viewModel.onCycleDescriptionChange(it) },
            onAddSubject = { subjectId, mins -> viewModel.addSubjectToCycleDraft(subjectId, mins) },
            onRemoveSubject = { viewModel.removeSubjectFromCycleDraft(it) },
            onUpdateDuration = { subjectId, mins -> viewModel.updateCycleDraftItemDuration(subjectId, mins) },
            onDismiss = { viewModel.closeCycleDialog() },
            onSave = { viewModel.saveCycle() }
        )
    }

    if (uiState.showAddEditScheduleDialog) {
        AddEditScheduleDialog(
            isEditing = uiState.editingSchedule != null,
            dayOfWeek = uiState.scheduleDayOfWeek,
            startHour = uiState.scheduleStartHour,
            startMinute = uiState.scheduleStartMinute,
            endHour = uiState.scheduleEndHour,
            endMinute = uiState.scheduleEndMinute,
            subjectId = uiState.scheduleSubjectId,
            topic = uiState.scheduleTopicInput,
            label = uiState.scheduleLabelInput,
            availableSubjects = subjects,
            errorMessage = uiState.scheduleError,
            onUpdate = { day, sH, sM, eH, eM, sId, t, l ->
                viewModel.updateScheduleForm(day, sH, sM, eH, eM, sId, t, l)
            },
            onDismiss = { viewModel.closeScheduleDialog() },
            onSave = { viewModel.saveSchedule() }
        )
    }

    if (uiState.showAddEditAgendaDialog) {
        AddEditAgendaDialog(
            isEditing = uiState.editingAgenda != null,
            name = uiState.agendaNameInput,
            description = uiState.agendaDescriptionInput,
            errorMessage = uiState.agendaError,
            onNameChange = { viewModel.onAgendaNameChange(it) },
            onDescriptionChange = { viewModel.onAgendaDescriptionChange(it) },
            onDismiss = { viewModel.closeAgendaDialog() },
            onSave = { viewModel.saveAgenda() }
        )
    }
}

