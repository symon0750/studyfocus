package com.example.ui.pomodoro

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.automirrored.filled.MenuBook

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SubjectEntity
import com.example.data.repository.ReviewStatus
import com.example.data.repository.TopicPendingPomodoroItem
import com.example.data.repository.TopicReviewItem
import com.example.ui.theme.*

@Composable
fun CollapsibleReviewsSection(
    reviews: List<TopicReviewItem>,
    topicsAwaitingPomodoros: List<TopicPendingPomodoroItem> = emptyList(),
    isExpanded: Boolean,
    selectedFilter: ReviewFilter,
    onToggleExpanded: () -> Unit,
    onSelectFilter: (ReviewFilter) -> Unit,
    onStartReview: (TopicReviewItem) -> Unit,
    onCompleteReview: (TopicReviewItem) -> Unit,
    onOpenAddReview: () -> Unit,
    onDeleteReview: (TopicReviewItem) -> Unit,
    onStartFocusPending: (String, Long?) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val todayReviews = remember(reviews) { reviews.filter { it.status == ReviewStatus.READY } }
    val futureReviews = remember(reviews) { reviews.filter { it.status == ReviewStatus.UPCOMING } }

    val filteredList = remember(reviews, selectedFilter) {
        when (selectedFilter) {
            ReviewFilter.TODAY -> todayReviews
            ReviewFilter.UPCOMING -> futureReviews
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("collapsible_reviews_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Cabeçalho / Botão Recolhível
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpanded() }
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .testTag("reviews_header_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (todayReviews.isNotEmpty()) Color(0xFF10B981).copy(alpha = 0.2f)
                                else BreakGreen.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = if (todayReviews.isNotEmpty()) Color(0xFF10B981) else BreakGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Revisões de Assuntos",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (todayReviews.isNotEmpty()) Color(0xFF10B981) else SurfaceCardBorder)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${todayReviews.size} hoje",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        val subtitleText = when {
                            todayReviews.isNotEmpty() -> "${todayReviews.size} revisão prevista para hoje • Toque para ver"
                            reviews.isNotEmpty() -> "${futureReviews.size} revisões futuras agendadas"
                            else -> "Conclua 2 pomodoros de um assunto para agendar revisões"
                        }

                        Text(
                            text = subtitleText,
                            fontSize = 12.sp,
                            color = if (todayReviews.isNotEmpty()) Color(0xFF10B981) else TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onToggleExpanded() },
                        modifier = Modifier.testTag("reviews_expand_button")
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isExpanded) "Recolher revisões" else "Expandir revisões",
                            tint = TextSecondary
                        )
                    }
                }
            }

            // Conteúdo Expandido (Filtros, Lista e Ações)
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .padding(bottom = 16.dp)
                ) {
                    androidx.compose.material3.HorizontalDivider(
                        color = SurfaceCardBorder,
                        thickness = 1.dp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Barra Superior: Filtros (Hoje / Futuras) & Botão "+ Novo Assunto"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ReviewFilter.values().forEach { filter ->
                            val isSelected = selectedFilter == filter
                            val count = when (filter) {
                                ReviewFilter.TODAY -> todayReviews.size
                                ReviewFilter.UPCOMING -> futureReviews.size
                            }

                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectFilter(filter) },
                                label = {
                                    Text(
                                        text = "${filter.label} ($count)",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (filter == ReviewFilter.TODAY) Color(0xFF10B981) else PomodoroRed,
                                    selectedLabelColor = Color.White,
                                    containerColor = BackgroundDark,
                                    labelColor = TextSecondary
                                ),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.testTag("review_filter_${filter.name.lowercase()}")
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        OutlinedButton(
                            onClick = onOpenAddReview,
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PomodoroRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PomodoroRed),
                            modifier = Modifier.testTag("add_review_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Novo Assunto", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (filteredList.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BackgroundDark,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (reviews.isEmpty()) "Nenhum assunto com 2 pomodoros concluídos ainda" else "Nenhuma revisão neste filtro",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Conclua 2 pomodoros de estudo em qualquer assunto no timer. Ele entrará automaticamente no ciclo de revisões periódicas!",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onOpenAddReview,
                                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Cadastrar Assunto com Estudo")
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            filteredList.forEach { item ->
                                ReviewItemCard(
                                    item = item,
                                    onStartReview = { onStartReview(item) },
                                    onCompleteReview = { onCompleteReview(item) },
                                    onDelete = { onDeleteReview(item) }
                                )
                            }
                        }
                    }

                    // Seção de Assuntos em Preparação (1 de 2 pomodoros concluídos)
                    if (topicsAwaitingPomodoros.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.HourglassEmpty,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Assuntos aguardando 2º pomodoro para agendar revisão:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            topicsAwaitingPomodoros.forEach { pending ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = BackgroundDark,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = pending.topicName,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "${pending.subjectName} • 1/2 pomodoros concluídos",
                                                fontSize = 11.sp,
                                                color = Color(0xFFF59E0B)
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = { onStartFocusPending(pending.topicName, pending.subjectId) },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, PomodoroRed),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PomodoroRed)
                                        ) {
                                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "Completar 2º Pomodoro", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Instruções recolhíveis posicionadas na parte inferior
                    var showExplanation by remember { mutableStateOf(false) }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = BackgroundDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showExplanation = !showExplanation }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = PomodoroRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Como funcionam as revisões?",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                }
                                Icon(
                                    imageVector = if (showExplanation) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            AnimatedVisibility(visible = showExplanation) {
                                Column(modifier = Modifier.padding(top = 8.dp)) {
                                    Text(
                                        text = "• Agendamento automático: ao concluir 2 pomodoros completos de um assunto.\n• Sem atrasos: revisões não vencem nem atrasam. A próxima data é sempre calculada a partir da última sessão realizada.\n• Ciclo de revisões periódicas: 1 dia, 7 dias, 15 dias e 30 dias.",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Botão inferior para recolher a lista
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        TextButton(
                            onClick = onToggleExpanded,
                            modifier = Modifier.testTag("collapse_reviews_bottom_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExpandLess,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Recolher Revisões", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private data class ReviewProgressBadge(
    val text: String,
    val isCompleted: Boolean,
    val isToday: Boolean,
    val isFuture: Boolean
)

private fun getReviewBadges(item: TopicReviewItem): List<ReviewProgressBadge> {
    val count = item.reviewCount
    val isReady = item.status == ReviewStatus.READY

    return when {
        count == 0 -> {
            val currentText = if (isReady) "1d — hoje" else if (item.daysDiff > 0) "1d — em ${item.daysDiff}d" else "1d"
            listOf(
                ReviewProgressBadge(text = currentText, isCompleted = false, isToday = isReady, isFuture = !isReady),
                ReviewProgressBadge(text = "7d", isCompleted = false, isToday = false, isFuture = true),
                ReviewProgressBadge(text = "15d", isCompleted = false, isToday = false, isFuture = true)
            )
        }
        count == 1 -> {
            val currentText = if (isReady) "7d — hoje" else if (item.daysDiff > 0) "7d — em ${item.daysDiff}d" else "7d"
            listOf(
                ReviewProgressBadge(text = "✓ 1d", isCompleted = true, isToday = false, isFuture = false),
                ReviewProgressBadge(text = currentText, isCompleted = false, isToday = isReady, isFuture = !isReady),
                ReviewProgressBadge(text = "15d", isCompleted = false, isToday = false, isFuture = true)
            )
        }
        count == 2 -> {
            val currentText = if (isReady) "15d — hoje" else if (item.daysDiff > 0) "15d — em ${item.daysDiff}d" else "15d"
            listOf(
                ReviewProgressBadge(text = "✓ 7d", isCompleted = true, isToday = false, isFuture = false),
                ReviewProgressBadge(text = currentText, isCompleted = false, isToday = isReady, isFuture = !isReady),
                ReviewProgressBadge(text = "30d", isCompleted = false, isToday = false, isFuture = true)
            )
        }
        count == 3 -> {
            val currentText = if (isReady) "30d — hoje" else if (item.daysDiff > 0) "30d — em ${item.daysDiff}d" else "30d"
            listOf(
                ReviewProgressBadge(text = "✓ 15d", isCompleted = true, isToday = false, isFuture = false),
                ReviewProgressBadge(text = currentText, isCompleted = false, isToday = isReady, isFuture = !isReady),
                ReviewProgressBadge(text = "30d", isCompleted = false, isToday = false, isFuture = true)
            )
        }
        else -> {
            val currentText = if (isReady) "30d — hoje" else if (item.daysDiff > 0) "30d — em ${item.daysDiff}d" else "30d"
            listOf(
                ReviewProgressBadge(text = "✓ 30d", isCompleted = true, isToday = false, isFuture = false),
                ReviewProgressBadge(text = currentText, isCompleted = false, isToday = isReady, isFuture = !isReady),
                ReviewProgressBadge(text = "30d", isCompleted = false, isToday = false, isFuture = true)
            )
        }
    }
}

@Composable
private fun ReviewItemCard(
    item: TopicReviewItem,
    onStartReview: () -> Unit,
    onCompleteReview: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("review_item_${item.topicId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BackgroundDark),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (item.status == ReviewStatus.READY) Color(0xFF10B981) else SurfaceCardBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Nome do Assunto e Ação de Excluir
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.topicName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    if (item.subjectName.isNotBlank() && item.subjectName != "Sem Matéria") {
                        val subColor = try {
                            Color(android.graphics.Color.parseColor(item.subjectColorHex))
                        } catch (_: Exception) {
                            TextSecondary
                        }
                        Text(
                            text = item.subjectName,
                            fontSize = 12.sp,
                            color = subColor,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("delete_review_button_${item.topicId}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Remover assunto das revisões",
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Indicadores cronológicos claros e objetivos: [✓ 1d] [7d — hoje] [15d]
            val badges = getReviewBadges(item)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                badges.forEach { badge ->
                    val bgColor = when {
                        badge.isToday -> Color(0xFF10B981).copy(alpha = 0.22f)
                        badge.isCompleted -> SurfaceCard
                        badge.isFuture -> BackgroundDark
                        else -> PomodoroRed.copy(alpha = 0.16f)
                    }
                    val borderColor = when {
                        badge.isToday -> Color(0xFF10B981)
                        badge.isCompleted -> Color(0xFF10B981).copy(alpha = 0.6f)
                        badge.isFuture -> SurfaceCardBorder
                        else -> PomodoroRed
                    }
                    val textColor = when {
                        badge.isToday -> Color(0xFF10B981)
                        badge.isCompleted -> Color(0xFF10B981)
                        badge.isFuture -> TextMuted
                        else -> PomodoroRed
                    }
                    val isBold = badge.isToday || badge.isCompleted

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = bgColor,
                        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
                    ) {
                        Text(
                            text = badge.text,
                            color = textColor,
                            fontSize = 12.sp,
                            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Botões de Ação Simples e Objetivos
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onStartReview,
                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("start_review_button_${item.topicId}")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Revisar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onCompleteReview,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BreakGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BreakGreen),
                    modifier = Modifier.testTag("complete_review_button_${item.topicId}")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Concluir", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun AddReviewDialog(
    subjects: List<SubjectEntity>,
    selectedSubjectId: Long?,
    topicInput: String,
    markStudiedToday: Boolean,
    errorMessage: String?,
    onSubjectSelected: (Long) -> Unit,
    onTopicChange: (String) -> Unit,
    onMarkStudiedChange: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.HistoryEdu,
                    contentDescription = null,
                    tint = PomodoroRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Agendar Revisão de Assunto",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Cadastre um assunto. Ao marcar 'Estudado hoje', 2 pomodoros são contabilizados e a revisão entra automaticamente no ciclo. Cada revisão é calculada a partir da última sessão e nunca atrasa.",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                // 1. Seleção de Disciplina
                Text(text = "Disciplina:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subjects.isEmpty()) {
                    Text(text = "Nenhuma disciplina cadastrada.", fontSize = 12.sp, color = TextMuted)
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        subjects.forEach { subject ->
                            val isSelected = selectedSubjectId == subject.id
                            val color = try {
                                Color(android.graphics.Color.parseColor(subject.colorHex))
                            } catch (_: Exception) {
                                PomodoroRed
                            }

                            FilterChip(
                                selected = isSelected,
                                onClick = { onSubjectSelected(subject.id) },
                                label = { Text(subject.name, fontSize = 12.sp) },
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = color.copy(alpha = 0.25f),
                                    selectedLabelColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }

                // 2. Campo do Assunto
                OutlinedTextField(
                    value = topicInput,
                    onValueChange = onTopicChange,
                    label = { Text("Nome do Assunto") },
                    placeholder = { Text("Ex: Funções Trigonométricas, Sintaxe...") },
                    singleLine = true,
                    isError = errorMessage != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_review_topic_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                if (errorMessage != null) {
                    Text(text = errorMessage, color = PomodoroRed, fontSize = 12.sp)
                }

                // 3. Opção de Estudo Inicial
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onMarkStudiedChange(!markStudiedToday) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = markStudiedToday,
                        onCheckedChange = onMarkStudiedChange,
                        colors = CheckboxDefaults.colors(checkedColor = PomodoroRed)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Assunto estudado hoje (2 pomodoros completos)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Ativa o ciclo: 1ª revisão calculada para 24h após o estudo",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                modifier = Modifier.testTag("confirm_add_review_button")
            ) {
                Text("Agendar Revisão")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}

private fun formatReviewDate(epochMs: Long): String {
    if (epochMs <= 0) return "Nenhuma"
    return try {
        val date = java.time.Instant.ofEpochMilli(epochMs)
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate()
        val today = java.time.LocalDate.now()
        val diff = java.time.temporal.ChronoUnit.DAYS.between(today, date)
        when {
            diff == 0L -> "Hoje"
            diff == 1L -> "Amanhã"
            diff == -1L -> "Ontem"
            diff < -1L -> "Há ${-diff} dias"
            diff in 2L..6L -> "Em $diff dias"
            else -> String.format(java.util.Locale.getDefault(), "%02d/%02d/%04d", date.dayOfMonth, date.monthValue, date.year)
        }
    } catch (_: Exception) {
        "Data indefinida"
    }
}

private fun formatTimestamp(epochMs: Long): String {
    if (epochMs <= 0) return "Nenhuma"
    return try {
        val date = java.time.Instant.ofEpochMilli(epochMs)
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate()
        String.format(java.util.Locale.getDefault(), "%02d/%02d", date.dayOfMonth, date.monthValue)
    } catch (_: Exception) {
        ""
    }
}


