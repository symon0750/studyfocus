package com.example.ui.pomodoro

import androidx.compose.ui.text.style.TextAlign

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyAgendaEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.domain.model.StudyType
import com.example.ui.theme.*

@Composable
fun PreSessionSetupDialog(
    studyMode: PomodoroStudyMode,
    cycles: List<StudyCycleEntity>,
    cycleItems: List<CycleItemWithSubject>,
    schedules: List<ScheduleWithSubject>,
    agendas: List<StudyAgendaEntity> = emptyList(),
    selectedCycleId: Long?,
    selectedAgendaId: Long? = null,
    selectedScheduleDayOfWeek: Int,
    selectedScheduleId: Long?,
    topicInput: String,
    selectedSubject: SubjectEntity?,
    selectedStudyType: StudyType,
    subjects: List<SubjectEntity>,
    topics: List<TopicEntity>,
    errorMessage: String?,
    isAutoLinked: Boolean,
    onModeSelected: (PomodoroStudyMode) -> Unit,
    onCycleSelected: (Long) -> Unit,
    onCycleSubjectSelected: (CycleItemWithSubject) -> Unit,
    onAgendaSelected: (Long) -> Unit = {},
    onScheduleDaySelected: (Int) -> Unit,
    onScheduleSelected: (ScheduleWithSubject) -> Unit,
    onTopicChange: (String) -> Unit,
    onTopicSelectedFromList: (TopicEntity) -> Unit,
    onSubjectSelected: (SubjectEntity) -> Unit,
    onStudyTypeSelected: (StudyType) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_pre_session_dialog")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fechar janela",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Alternador de Modo de Estudo (Segmented Tab Bar)
                Column {
                    Text(
                        text = "Modo de Planejamento",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(BackgroundDark)
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Aba: Ciclos de Estudo
                        val isCycle = studyMode == PomodoroStudyMode.CYCLE
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCycle) PomodoroRed else Color.Transparent)
                                .clickable { onModeSelected(PomodoroStudyMode.CYCLE) }
                                .padding(vertical = 8.dp)
                                .testTag("mode_cycle_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Loop,
                                    contentDescription = null,
                                    tint = if (isCycle) Color.White else TextMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Ciclos",
                                    color = if (isCycle) Color.White else TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isCycle) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }

                        // Aba: Agenda de Horários
                        val isSchedule = studyMode == PomodoroStudyMode.SCHEDULE
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSchedule) PomodoroRed else Color.Transparent)
                                .clickable { onModeSelected(PomodoroStudyMode.SCHEDULE) }
                                .padding(vertical = 8.dp)
                                .testTag("mode_schedule_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = if (isSchedule) Color.White else TextMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Agendas",
                                    color = if (isSchedule) Color.White else TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSchedule) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }

                        // Aba: Modo Livre
                        val isFree = studyMode == PomodoroStudyMode.FREE
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isFree) PomodoroRed else Color.Transparent)
                                .clickable { onModeSelected(PomodoroStudyMode.FREE) }
                                .padding(vertical = 8.dp)
                                .testTag("mode_free_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = if (isFree) Color.White else TextMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Livre",
                                    color = if (isFree) Color.White else TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isFree) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // 2. Conteúdo de Seleção de acordo com o Modo
                when (studyMode) {
                    PomodoroStudyMode.CYCLE -> {
                        if (cycles.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BackgroundDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Nenhum ciclo de estudos cadastrado ainda.",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Crie seus ciclos na aba 'Disciplinas' para organizar matérias em bloco, ou utilize o Modo Livre para estudar agora.",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TextButton(
                                        onClick = { onModeSelected(PomodoroStudyMode.FREE) },
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                    ) {
                                        Text("Usar Modo Livre", color = PomodoroRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        } else {
                            val activeCycleId = selectedCycleId ?: cycles.first().id
                            val activeCycle = cycles.find { it.id == activeCycleId } ?: cycles.first()
                            val items = cycleItems.filter { it.cycleId == activeCycle.id }
                            val totalMinutes = items.sumOf { it.targetMinutes }.coerceAtLeast(1)

                            // Seletor de Ciclos (se houver mais de um)
                            if (cycles.size > 1) {
                                Column {
                                    Text(
                                        text = "Ciclo Ativo:",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        cycles.forEach { cycle ->
                                            val isSelected = cycle.id == activeCycle.id
                                            Surface(
                                                modifier = Modifier.clickable { onCycleSelected(cycle.id) },
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (isSelected) PomodoroRed.copy(alpha = 0.2f) else BackgroundDark,
                                                border = androidx.compose.foundation.BorderStroke(
                                                    1.dp,
                                                    if (isSelected) PomodoroRed else SurfaceCardBorder
                                                )
                                            ) {
                                                Text(
                                                    text = cycle.name,
                                                    color = if (isSelected) Color.White else TextSecondary,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    fontSize = 12.sp,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Barra visual de proporção do ciclo
                            if (items.isNotEmpty()) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${activeCycle.name} • ${items.size} matérias",
                                            fontSize = 11.sp,
                                            color = TextSecondary,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "${totalMinutes} min totais",
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(BackgroundDark)
                                    ) {
                                        items.forEach { item ->
                                            val color = try {
                                                Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                            } catch (_: Exception) {
                                                PomodoroRed
                                            }
                                            val weight = (item.targetMinutes.toFloat() / totalMinutes.toFloat()).coerceAtLeast(0.01f)
                                            Box(
                                                modifier = Modifier
                                                    .weight(weight)
                                                    .fillMaxHeight()
                                                    .background(color)
                                            )
                                        }
                                    }
                                }

                                // Lista de Matérias do Ciclo
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "Toque na matéria para focar:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    items.forEach { item ->
                                        val isCurrentSubject = selectedSubject?.id == item.subjectId
                                        val subjectColor = try {
                                            Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                        } catch (_: Exception) {
                                            PomodoroRed
                                        }
                                        val percent = ((item.targetMinutes * 100) / totalMinutes)

                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onCycleSubjectSelected(item) },
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isCurrentSubject) subjectColor.copy(alpha = 0.16f) else BackgroundDark,
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isCurrentSubject) 2.dp else 1.dp,
                                                color = if (isCurrentSubject) subjectColor else SurfaceCardBorder
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(10.dp)
                                                            .clip(CircleShape)
                                                            .background(subjectColor)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = item.subjectName,
                                                        fontSize = 13.sp,
                                                        fontWeight = if (isCurrentSubject) FontWeight.Bold else FontWeight.Medium,
                                                        color = TextPrimary
                                                    )
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "${item.targetMinutes}m ($percent%)",
                                                        fontSize = 12.sp,
                                                        color = if (isCurrentSubject) subjectColor else TextMuted,
                                                        fontWeight = if (isCurrentSubject) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (isCurrentSubject) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Icon(
                                                            imageVector = Icons.Default.Check,
                                                            contentDescription = "Selecionada",
                                                            tint = subjectColor,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Campo de Assunto / Detalhe Específico (preenchido com nome da matéria ou customizado)
                                Column {
                                    Text(
                                        text = "Tópico / Assunto específico:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedTextField(
                                        value = topicInput,
                                        onValueChange = onTopicChange,
                                        placeholder = { Text("Ex: Exercícios 1 a 10, Capítulo 3") },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("pre_session_topic_input"),
                                        singleLine = true
                                    )
                                }
                            } else {
                                Text(
                                    text = "Nenhuma matéria cadastrada neste ciclo.",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    PomodoroStudyMode.SCHEDULE -> {
                        if (schedules.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BackgroundDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Nenhuma agenda cadastrada ainda.",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Cadastre seus horários semanais na aba 'Disciplinas' para focar de acordo com sua grade horária.",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TextButton(
                                        onClick = { onModeSelected(PomodoroStudyMode.FREE) },
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                    ) {
                                        Text("Usar Modo Livre", color = PomodoroRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        } else {
                            // Seletor de Agendas (quando houver mais de uma cadastrada)
                            val activeAgendaId = selectedAgendaId ?: agendas.firstOrNull()?.id ?: 1L
                            if (agendas.size > 1) {
                                Column {
                                    Text(
                                        text = "Agenda Selecionada:",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        agendas.forEach { agenda ->
                                            val isSelected = agenda.id == activeAgendaId
                                            Surface(
                                                modifier = Modifier.clickable { onAgendaSelected(agenda.id) },
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (isSelected) PomodoroRed.copy(alpha = 0.2f) else BackgroundDark,
                                                border = androidx.compose.foundation.BorderStroke(
                                                    1.dp,
                                                    if (isSelected) PomodoroRed else SurfaceCardBorder
                                                )
                                            ) {
                                                Text(
                                                    text = agenda.name,
                                                    color = if (isSelected) Color.White else TextSecondary,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    fontSize = 12.sp,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            // Seletor de Dias da Semana
                            val days = listOf("Seg" to 1, "Ter" to 2, "Qua" to 3, "Qui" to 4, "Sex" to 5, "Sáb" to 6, "Dom" to 7)
                            Column {
                                Text(
                                    text = "Dia da Semana:",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    days.forEach { (label, dayNum) ->
                                        val isSelected = selectedScheduleDayOfWeek == dayNum
                                        Surface(
                                            modifier = Modifier.clickable { onScheduleDaySelected(dayNum) },
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (isSelected) PomodoroRed.copy(alpha = 0.2f) else BackgroundDark,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSelected) PomodoroRed else SurfaceCardBorder
                                            )
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) Color.White else TextSecondary,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Horários programados para o dia na agenda selecionada
                            val daySchedules = schedules.filter {
                                (it.agendaId == activeAgendaId || (activeAgendaId == 1L && it.agendaId == 0L)) && it.dayOfWeek == selectedScheduleDayOfWeek
                            }
                            if (daySchedules.isEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = BackgroundDark,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Sem horários programados para este dia na grade.",
                                        fontSize = 12.sp,
                                        color = TextMuted,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "Toque no horário agendado:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    daySchedules.forEach { item ->
                                        val isSelected = selectedScheduleId == item.id && selectedSubject?.id == item.subjectId
                                        val subjectColor = try {
                                            Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                        } catch (_: Exception) {
                                            PomodoroRed
                                        }
                                        val timeStr = String.format(java.util.Locale.getDefault(), "%02d:%02d - %02d:%02d", item.startHour, item.startMinute, item.endHour, item.endMinute)

                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onScheduleSelected(item) },
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isSelected) subjectColor.copy(alpha = 0.16f) else BackgroundDark,
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) subjectColor else SurfaceCardBorder
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(10.dp)
                                                            .clip(CircleShape)
                                                            .background(subjectColor)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Column {
                                                        Text(
                                                            text = item.subjectName,
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = TextPrimary
                                                        )
                                                        if (item.topic.isNotBlank() || item.label.isNotBlank()) {
                                                            Text(
                                                                text = item.topic.ifBlank { item.label },
                                                                fontSize = 11.sp,
                                                                color = TextSecondary
                                                            )
                                                        }
                                                    }
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = timeStr,
                                                        fontSize = 11.sp,
                                                        color = if (isSelected) subjectColor else TextMuted,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    if (isSelected) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Icon(
                                                            imageVector = Icons.Default.Check,
                                                            contentDescription = "Selecionado",
                                                            tint = subjectColor,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Campo de Tópico / Assunto
                                Column {
                                    Text(
                                        text = "Tópico / Assunto específico:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedTextField(
                                        value = topicInput,
                                        onValueChange = onTopicChange,
                                        placeholder = { Text("Ex: Tópico específico da aula") },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("pre_session_topic_input"),
                                        singleLine = true
                                    )
                                }
                            }
                        }
                    }

                    PomodoroStudyMode.FREE -> {
                        // Modo Livre: Entrada de Assunto + Seleção de Matéria
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            // Assunto
                            Column {
                                Text(
                                    text = "Qual assunto você vai estudar?",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = topicInput,
                                    onValueChange = onTopicChange,
                                    placeholder = { Text("Ex: Funções Afins, Revolução Industrial") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("pre_session_topic_input"),
                                    singleLine = true
                                )

                                // Sugestões rápidas de assuntos anteriores
                                if (topics.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        topics.take(6).forEach { topicItem ->
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = SurfaceCard,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                                                modifier = Modifier.clickable { onTopicSelectedFromList(topicItem) }
                                            ) {
                                                Text(
                                                    text = topicItem.name,
                                                    fontSize = 11.sp,
                                                    color = TextSecondary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Matéria Vinculada
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Matéria Vinculada",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    if (isAutoLinked) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = BreakGreen,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Vínculo Automático",
                                                fontSize = 11.sp,
                                                color = BreakGreen,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    subjects.forEach { subject ->
                                        val isSelected = selectedSubject?.id == subject.id
                                        val color = try {
                                            Color(android.graphics.Color.parseColor(subject.colorHex))
                                        } catch (_: Exception) {
                                            PomodoroRed
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(16.dp),
                                            color = if (isSelected) color.copy(alpha = 0.2f) else BackgroundDark,
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) color else SurfaceCardBorder
                                            ),
                                            modifier = Modifier
                                                .clickable { onSubjectSelected(subject) }
                                                .testTag("subject_chip_${subject.id}")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .clip(CircleShape)
                                                        .background(color)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = subject.name,
                                                    fontSize = 13.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) TextPrimary else TextSecondary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Tipo de Estudo (Presente em todos os modos)
                Column {
                    Text(
                        text = "Tipo de Estudo",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudyType.values().forEach { type ->
                            val isSelected = selectedStudyType == type
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) PomodoroRed.copy(alpha = 0.18f) else BackgroundDark,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) PomodoroRed else SurfaceCardBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStudyTypeSelected(type) }
                                    .testTag("study_type_${type.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = type.icon,
                                        contentDescription = type.label,
                                        modifier = Modifier.size(22.dp),
                                        tint = if (isSelected) PomodoroRed else TextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = type.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) PomodoroRed else TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Card de Prévia / Resumo da Sessão
                val subjectColor = selectedSubject?.colorHex?.let {
                    try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { PomodoroRed }
                } ?: PomodoroRed

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BackgroundDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(subjectColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = selectedSubject?.name ?: "Selecione uma matéria",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedSubject != null) TextPrimary else TextMuted
                                )
                                Text(
                                    text = topicInput.ifBlank { "Defina o assunto do foco" },
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PomodoroRed.copy(alpha = 0.15f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = selectedStudyType.icon,
                                    contentDescription = null,
                                    tint = PomodoroRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedStudyType.label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PomodoroRed
                                )
                            }
                        }
                    }
                }

                // Mensagem de Erro
                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PomodoroRed.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PomodoroRed)
                    ) {
                        Text(
                            text = errorMessage,
                            color = PomodoroRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_pre_session_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Iniciar Foco", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(20.dp)
    )
}
