package com.example

import com.example.domain.model.PomodoroPhase
import com.example.domain.model.TimerState
import com.example.service.FocusBlockManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class FocusBlockManagerTest {

    @Before
    fun setup() {
        FocusBlockManager.updateBlockerData(
            enabled = true,
            blockDuringBreaks = false,
            strictMode = false,
            blockedPackages = setOf(
                "com.google.android.youtube",
                "com.facebook.katana",
                "com.instagram.android",
                "com.zhiliaoapp.musically"
            ),
            blockedDomains = setOf(
                "youtube.com",
                "facebook.com",
                "instagram.com",
                "tiktok.com",
                "twitter.com",
                "x.com"
            )
        )

        FocusBlockManager.updatePomodoroState(
            state = TimerState.RUNNING,
            phase = PomodoroPhase.FOCUS,
            remainingSeconds = 1500,
            subjectName = "Matemática",
            topicName = "Álgebra"
        )
    }

    @Test
    fun shouldBlockPackage_whenFocusRunningAndInBlocklist_returnsTrue() {
        assertTrue(FocusBlockManager.shouldBlockPackage("com.google.android.youtube", "com.example"))
        assertTrue(FocusBlockManager.shouldBlockPackage("com.facebook.katana", "com.example"))
        assertTrue(FocusBlockManager.shouldBlockPackage("com.instagram.android", "com.example"))
    }

    @Test
    fun shouldBlockPackage_handlesFamilyAliasesForYoutubeAndFacebook() {
        // YouTube Music é bloqueado pelo alias de família do YouTube
        assertTrue(FocusBlockManager.shouldBlockPackage("com.google.android.apps.youtube.music", "com.example"))
        // Facebook Lite é bloqueado pelo alias de família do Facebook
        assertTrue(FocusBlockManager.shouldBlockPackage("com.facebook.lite", "com.example"))
    }

    @Test
    fun shouldBlockPackage_whenNotBlocked_returnsFalse() {
        assertFalse(FocusBlockManager.shouldBlockPackage("com.unrelated.app", "com.example"))
    }

    @Test
    fun shouldBlockPackage_neverBlocksOwnApp() {
        assertFalse(FocusBlockManager.shouldBlockPackage("com.example", "com.example"))
    }

    @Test
    fun shouldBlockPackage_neverBlocksEssentialSystemPackages() {
        assertFalse(FocusBlockManager.shouldBlockPackage("com.android.settings", "com.example"))
        assertFalse(FocusBlockManager.shouldBlockPackage("com.android.systemui", "com.example"))
        assertFalse(FocusBlockManager.shouldBlockPackage("com.android.phone", "com.example"))
        assertFalse(FocusBlockManager.shouldBlockPackage("com.google.android.dialer", "com.example"))
    }

    @Test
    fun shouldBlockPackage_whenTimerPaused_returnsFalse() {
        FocusBlockManager.updatePomodoroState(
            state = TimerState.PAUSED,
            phase = PomodoroPhase.FOCUS,
            remainingSeconds = 1200,
            subjectName = "Matemática",
            topicName = "Álgebra"
        )
        assertFalse(FocusBlockManager.shouldBlockPackage("com.google.android.youtube", "com.example"))
    }

    @Test
    fun shouldBlockPackage_duringBreak_respectsBlockDuringBreaksSetting() {
        // Break com blockDuringBreaks = false
        FocusBlockManager.updatePomodoroState(
            state = TimerState.RUNNING,
            phase = PomodoroPhase.SHORT_BREAK,
            remainingSeconds = 300,
            subjectName = "Matemática",
            topicName = "Álgebra"
        )
        assertFalse(FocusBlockManager.shouldBlockPackage("com.google.android.youtube", "com.example"))

        // Habilita blockDuringBreaks
        FocusBlockManager.updateBlockerData(
            enabled = true,
            blockDuringBreaks = true,
            strictMode = false,
            blockedPackages = setOf("com.google.android.youtube"),
            blockedDomains = setOf("youtube.com")
        )
        FocusBlockManager.updatePomodoroState(
            state = TimerState.RUNNING,
            phase = PomodoroPhase.SHORT_BREAK,
            remainingSeconds = 300,
            subjectName = "Matemática",
            topicName = "Álgebra"
        )
        assertTrue(FocusBlockManager.shouldBlockPackage("com.google.android.youtube", "com.example"))
    }

    @Test
    fun extractDomain_sanitizesCorrectly() {
        assertEquals("instagram.com", FocusBlockManager.extractDomain("https://www.instagram.com/reels/xyz"))
        assertEquals("m.tiktok.com", FocusBlockManager.extractDomain("http://m.tiktok.com/@user"))
        assertEquals("tiktok.com", FocusBlockManager.extractDomain("https://tiktok.com/@user"))
        assertEquals("twitter.com", FocusBlockManager.extractDomain("twitter.com/explore"))
        assertEquals("reddit.com", FocusBlockManager.extractDomain("reddit.com"))
    }

    @Test
    fun shouldBlockUrl_detectsBlockedDomainAndSubdomainsForYoutubeAndFacebook() {
        assertEquals("youtube.com", FocusBlockManager.shouldBlockUrl("https://www.youtube.com/watch?v=123"))
        assertEquals("youtube.com", FocusBlockManager.shouldBlockUrl("m.youtube.com"))
        assertEquals("youtube.com", FocusBlockManager.shouldBlockUrl("https://youtu.be/abcdef"))
        assertEquals("facebook.com", FocusBlockManager.shouldBlockUrl("https://m.facebook.com/home"))
        assertEquals("facebook.com", FocusBlockManager.shouldBlockUrl("fb.com"))
        assertEquals("instagram.com", FocusBlockManager.shouldBlockUrl("https://www.instagram.com/p/123"))
        assertNull(FocusBlockManager.shouldBlockUrl("https://en.wikipedia.org/wiki/Kotlin"))
    }
}
