package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.database.StudyDatabase
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.repository.ReviewStatus
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TopicReviewCalculationTest {

    private lateinit var database: StudyDatabase
    private lateinit var repository: StudyRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, StudyDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = StudyRepository(
            subjectDao = database.subjectDao(),
            studySessionDao = database.studySessionDao(),
            topicDao = database.topicDao(),
            studyCycleDao = database.studyCycleDao(),
            studyScheduleDao = database.studyScheduleDao()
        )
    }

    @After
    fun closeDb() {
        database.close()
    }

    @Test
    fun testReviewCalculationBasedOnLastReviewSession() = runBlocking {
        // 1. Criar disciplina e assunto
        val subjectId = repository.createSubject("Matemática", "#3B82F6")
        repository.createTopic("Álgebra Linear", subjectId)

        val now = System.currentTimeMillis()
        val dayMs = 24L * 60 * 60 * 1000L

        // 2. Registrar a 1ª sessão de revisão ocorrida há 7 dias
        val reviewSessionTime = now - (7 * dayMs)
        repository.recordSession(
            subjectId = subjectId,
            topic = "Álgebra Linear",
            studyType = "REVIEW",
            phaseType = "FOCUS",
            targetDurationSeconds = 1500,
            actualDurationSeconds = 1500,
            startTimeEpochMs = reviewSessionTime - 1500000L,
            endTimeEpochMs = reviewSessionTime,
            completed = true,
            notes = "1ª Revisão concluída"
        )

        // 3. Obter as revisões agendadas calculadas reativamente pelo repositório
        val reviews = repository.scheduledReviews.first()
        val algebraReview = reviews.firstOrNull { it.topicName == "Álgebra Linear" }
        assertNotNull(algebraReview)
        algebraReview!!

        // A última revisão é exatamente a sessão que foi registrada
        assertEquals(reviewSessionTime, algebraReview.lastReviewDateEpochMs)
        assertEquals(1, algebraReview.reviewCount)
        assertEquals(7, algebraReview.intervalDays) // Próxima em 7 dias após a 1ª revisão
        assertEquals(ReviewStatus.READY, algebraReview.status) // Como passaram 7 dias, está disponível para revisão (sem atraso!)

        // 4. Concluir a 2ª revisão hoje
        repository.completeReview(subjectId, "Álgebra Linear", durationMinutes = 20)

        // 5. Verificar o recálculo imediato da 3ª revisão (15 dias a partir de HOJE)
        val updatedReviews = repository.scheduledReviews.first()
        val updatedAlgebra = updatedReviews.firstOrNull { it.topicName == "Álgebra Linear" }
        assertNotNull(updatedAlgebra)
        updatedAlgebra!!

        assertEquals(2, updatedAlgebra.reviewCount) // Já fez 2 revisões
        assertEquals(15, updatedAlgebra.intervalDays) // Próxima revisão em 15 dias calculada a partir da última sessão
        assertEquals(ReviewStatus.UPCOMING, updatedAlgebra.status)
        assertTrue(updatedAlgebra.daysDiff in 14L..15L)
    }

    @Test
    fun testTwoPomodorosAutomaticReviewSchedulingRule() = runBlocking {
        // Regra do Usuário: Agendadas automaticamente quando dois pomodoros completos de um assunto forem concluídos
        val subjectId = repository.createSubject("Química", "#10B981")
        repository.createTopic("Termoquímica", subjectId)

        val now = System.currentTimeMillis()

        // 1. Concluir 1 pomodoro de estudo completo
        repository.recordSession(
            subjectId = subjectId,
            topic = "Termoquímica",
            studyType = "THEORY",
            phaseType = "FOCUS",
            targetDurationSeconds = 1500,
            actualDurationSeconds = 1500,
            startTimeEpochMs = now - 3600000L,
            endTimeEpochMs = now - 2100000L,
            completed = true
        )

        // Com apenas 1 pomodoro, NÃO deve estar agendado ainda em scheduledReviews
        val reviewsWithOnePomodoro = repository.scheduledReviews.first()
        val pendingTopic = reviewsWithOnePomodoro.firstOrNull { it.topicName == "Termoquímica" }
        assertEquals(null, pendingTopic)

        // Deve aparecer em topicsAwaitingPomodoros (1/2 pomodoros)
        val awaitingList = repository.topicsAwaitingPomodoros.first()
        val awaitingItem = awaitingList.firstOrNull { it.topicName == "Termoquímica" }
        assertNotNull(awaitingItem)
        assertEquals(1, awaitingItem!!.completedPomodoros)

        // 2. Concluir o 2º pomodoro completo
        repository.recordSession(
            subjectId = subjectId,
            topic = "Termoquímica",
            studyType = "EXERCISES",
            phaseType = "FOCUS",
            targetDurationSeconds = 1500,
            actualDurationSeconds = 1500,
            startTimeEpochMs = now - 1800000L,
            endTimeEpochMs = now,
            completed = true
        )

        // Agora que concluiu 2 pomodoros completos, o agendamento foi ativado automaticamente!
        val reviewsWithTwoPomodoros = repository.scheduledReviews.first()
        val scheduledTopic = reviewsWithTwoPomodoros.firstOrNull { it.topicName == "Termoquímica" }
        assertNotNull(scheduledTopic)
        scheduledTopic!!

        assertEquals(0, scheduledTopic.reviewCount)
        assertEquals(2, scheduledTopic.completedPomodorosCount)
        assertEquals(1, scheduledTopic.intervalDays) // 1ª revisão calculada para 1 dia (24h) a partir do término do 2º pomodoro
        assertEquals(ReviewStatus.UPCOMING, scheduledTopic.status)
    }

    @Test
    fun testCreateNewTopicReviewWithInitialStudy() = runBlocking {
        val subjectId = repository.createSubject("História", "#EC4899")
        repository.createTopicReview(subjectId, "Revolução Francesa", hasInitialStudy = true)

        val reviews = repository.scheduledReviews.first()
        val histReview = reviews.firstOrNull { it.topicName == "Revolução Francesa" }
        assertNotNull(histReview)
        histReview!!

        assertEquals(0, histReview.reviewCount)
        assertEquals(1, histReview.intervalDays) // 1ª revisão em 24h após o estudo inicial
        assertNotNull(histReview.lastStudyDateEpochMs)
    }
}
