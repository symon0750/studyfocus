package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Shield
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppDestination(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    POMODORO("pomodoro", "Início", Icons.Default.Home),
    SUBJECTS("subjects", "Disciplinas", Icons.Default.Book),
    STATS_HISTORY("stats_history", "Desempenho & Histórico", Icons.Default.BarChart),
    BLOCKER("blocker", "Bloqueio", Icons.Default.Shield)
}
