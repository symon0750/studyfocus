package com.example.ui.pomodoro

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Timer
import com.example.data.local.dao.CycleItemWithSubject
import com.example.data.local.dao.ScheduleWithSubject
import com.example.data.local.entity.StudyCycleEntity
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.domain.model.PomodoroPhase
import com.example.domain.model.StudyType
import com.example.domain.model.TimerState
import com.example.domain.model.TimerTickState
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BreakGreen
import com.example.ui.theme.LongBreakBlue
import com.example.ui.theme.PomodoroRed
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun PomodoroScreen(
    viewModel: PomodoroViewModel,
    modifier: Modifier = Modifier
) {
    val timerTick by viewModel.timerState.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val topics by viewModel.topics.collectAsStateWithLifecycle()
    val cycles by viewModel.studyCycles.collectAsStateWithLifecycle()
    val cycleItems by viewModel.cycleItems.collectAsStateWithLifecycle()
    val schedules by viewModel.schedules.collectAsStateWithLifecycle()
    val todaySummary by viewModel.todaySummary.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val phaseColor by animateColorAsState(
        targetValue = when (timerTick.phase) {
            PomodoroPhase.FOCUS -> PomodoroRed
            PomodoroPhase.SHORT_BREAK -> BreakGreen
            PomodoroPhase.LONG_BREAK -> LongBreakBlue
        },
        animationSpec = tween(durationMillis = 400),
        label = "phaseColor"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Barra Superior: Indicador de Bloqueio e Configurações
        val blockState by com.example.service.FocusBlockManager.runtimeState.collectAsState()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (blockState.isFocusActive) PomodoroRed.copy(alpha = 0.15f) else SurfaceCard)
                    .border(
                        1.dp,
                        if (blockState.isFocusActive) PomodoroRed else SurfaceCardBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("pomodoro_block_status_chip")
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Status do Bloqueio",
                    tint = if (blockState.isFocusActive) PomodoroRed else BreakGreen,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (blockState.isFocusActive) "Bloqueio Ativo" else "Modo Protegido",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (blockState.isFocusActive) PomodoroRed else TextSecondary
                )
            }

            IconButton(
                onClick = { viewModel.toggleSettingsDialog(true) },
                modifier = Modifier.testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Configurar Durações",
                    tint = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Seletor de Modo de Estudo (Ciclos de Estudo / Agenda de Horários / Modo Livre)
        StudyModeSelectorSection(
            uiState = uiState,
            cycles = cycles,
            cycleItems = cycleItems,
            schedules = schedules,
            onModeSelected = { viewModel.setStudyMode(it) },
            onCycleSelected = { viewModel.selectStudyCycle(it) },
            onCycleSubjectSelected = { viewModel.selectSubjectFromCycle(it) },
            onScheduleDaySelected = { viewModel.setScheduleDayOfWeek(it) },
            onScheduleSelected = { viewModel.selectScheduleForStudy(it) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Fases do Pomodoro (Indicadores de Pílula)
        Row(
            modifier = Modifier
                .background(SurfaceCard, RoundedCornerShape(24.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            PomodoroPhase.values().forEach { phase ->
                val isCurrent = timerTick.phase == phase
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isCurrent) phaseColor else Color.Transparent)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = phase.label,
                        color = if (isCurrent) Color.White else TextMuted,
                        fontSize = 13.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Card de Metadados da Sessão Ativa (Assunto, Matéria Vinculada e Tipo de Estudo)
        if (uiState.isSessionConfigured && timerTick.phase == PomodoroPhase.FOCUS) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (timerTick.state != TimerState.RUNNING) {
                            viewModel.openPreSessionDialog()
                        }
                    },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.activeTopic,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val subjectColor = uiState.activeSubject?.colorHex?.let {
                                try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { PomodoroRed }
                            } ?: PomodoroRed

                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(subjectColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = uiState.activeSubject?.name ?: "Sem Matéria",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "•  ${uiState.activeStudyType.emoji} ${uiState.activeStudyType.label}",
                                color = phaseColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (timerTick.state != TimerState.RUNNING) {
                        IconButton(onClick = { viewModel.openPreSessionDialog() }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Editar Assunto",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        } else if (timerTick.phase == PomodoroPhase.FOCUS) {
            // Sessão não configurada: card convidativo para definir assunto antes de iniciar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.openPreSessionDialog() }
                    .testTag("configure_session_prompt"),
                shape = RoundedCornerShape(14.dp),
                color = SurfaceCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🎯 Toque em Iniciar para definir o assunto e começar",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mostrador Circular do Temporizador
        CircularTimerDisplay(
            timerTick = timerTick,
            accentColor = phaseColor
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Indicador de Ciclos do Pomodoro (● ○ ○ ○ Ciclo 1 de 4)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (i in 1..timerTick.totalCyclesInSet) {
                val isCompleted = i < timerTick.currentCycle
                val isCurrent = i == timerTick.currentCycle
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCompleted -> phaseColor
                                isCurrent -> phaseColor.copy(alpha = 0.8f)
                                else -> SurfaceCardBorder
                            }
                        )
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Ciclo ${timerTick.currentCycle} de ${timerTick.totalCyclesInSet}",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botões de Controle Principal (Reset, Play/Pause com disparo pré-sessão, Skip)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Botão Reset
            FilledTonalButton(
                onClick = { viewModel.requestStopOrReset() },
                modifier = Modifier
                    .size(54.dp)
                    .testTag("reset_button"),
                shape = CircleShape,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = SurfaceCard,
                    contentColor = TextSecondary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reiniciar",
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(24.dp))

            // Botão Principal Play / Pause
            val isRunning = timerTick.state == TimerState.RUNNING
            Button(
                onClick = { viewModel.onPlayOrPauseClicked(context) },
                modifier = Modifier
                    .size(76.dp)
                    .testTag("play_pause_button"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = phaseColor,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isRunning) "Pausar" else "Iniciar",
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.width(24.dp))

            // Botão Próxima Fase (Skip)
            FilledTonalButton(
                onClick = { viewModel.skipPhase() },
                modifier = Modifier
                    .size(54.dp)
                    .testTag("skip_phase_button"),
                shape = CircleShape,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = SurfaceCard,
                    contentColor = TextSecondary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Pular Fase",
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Ação rápida para contabilizar tempo de pomodoro incompleto
        if (timerTick.phase == PomodoroPhase.FOCUS && timerTick.elapsedSeconds > 0) {
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = { viewModel.requestStopOrReset() },
                modifier = Modifier
                    .testTag("save_incomplete_session_quick_button")
                    .height(42.dp),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFF59E0B)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                val mins = timerTick.elapsedSeconds / 60
                val secs = timerTick.elapsedSeconds % 60
                val timeLabel = if (mins > 0) "${mins}m ${secs}s" else "${secs}s"
                Text(
                    text = "Finalizar e Salvar Tempo ($timeLabel)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Resumo do Dia
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Foco Hoje",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val hours = todaySummary.totalSeconds / 3600
                    val minutes = (todaySummary.totalSeconds % 3600) / 60
                    Text(
                        text = if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .height(32.dp)
                        .width(1.dp)
                        .background(SurfaceCardBorder)
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Sessões Concluídas",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${todaySummary.completedSessions}",
                        color = PomodoroRed,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // DIÁLOGO OBRIGATÓRIO DE PRÉ-SESSÃO DE FOCO
    if (uiState.showPreSessionDialog) {
        PreSessionSetupDialog(
            topicInput = uiState.preSessionTopicInput,
            selectedSubject = uiState.preSessionSubjectSelected,
            selectedStudyType = uiState.preSessionStudyType,
            subjects = subjects,
            topics = topics,
            errorMessage = uiState.preSessionError,
            isAutoLinked = uiState.isTopicAutoLinked,
            onTopicChange = { viewModel.onPreSessionTopicChange(it) },
            onTopicSelectedFromList = { viewModel.selectPreSessionTopicFromList(it) },
            onSubjectSelected = { viewModel.onPreSessionSubjectSelect(it) },
            onStudyTypeSelected = { viewModel.onPreSessionStudyTypeSelect(it) },
            onDismiss = { viewModel.closePreSessionDialog() },
            onConfirm = { viewModel.confirmPreSessionAndStart() }
        )
    }

    // Diálogo de Permissão de Acessibilidade Necessária para o Bloqueador
    if (uiState.showPermissionWarningDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissPermissionWarning(startAnyway = false) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = Color(0xFFF59E0B),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Ativar Bloqueio no Android 🛡️",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Para que o StudyFocus consiga fechar e bloquear aplicativos selecionados (como YouTube e Facebook) e sites durante o foco, o Android exige que você ative o Serviço de Acessibilidade.",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Toque em 'Ativar nas Configurações' e ligue a chave 'StudyFocus - Bloqueio de Distrações'.",
                        color = Color(0xFFF59E0B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.openAccessibilitySettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("enable_accessibility_confirm_button")
                ) {
                    Text("Ativar nas Configurações", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.dismissPermissionWarning(startAnyway = true) },
                    modifier = Modifier.testTag("start_without_blocking_button")
                ) {
                    Text("Iniciar sem Bloqueio", color = TextSecondary)
                }
            },
            containerColor = SurfaceCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Caixa de diálogo de Conclusão da Sessão
    if (uiState.showCompletionDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissCompletionDialog() },
            title = {
                Text(
                    text = "🎉 Sessão Concluída!",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Você completou ${uiState.completedDurationSecs / 60} min de estudo em '${uiState.activeTopic.ifEmpty { "Estudo Geral" }}'!",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = uiState.sessionNotes,
                        onValueChange = { viewModel.updateNotes(it) },
                        label = { Text("Anotações da sessão (opcional)") },
                        placeholder = { Text("Ex: Finalizei exercícios 1 a 10") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("session_notes_input"),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.saveCompletedSession(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = phaseColor),
                    modifier = Modifier.testTag("save_session_button")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Salvar Registro")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissCompletionDialog() }) {
                    Text("Pular Anotação", color = TextSecondary)
                }
            }
        )
    }

    // Diálogo de Configuração de Durações
    if (uiState.showSettingsDialog) {
        TimerSettingsDialog(
            initialFocus = uiState.focusMinutes,
            initialShortBreak = uiState.shortBreakMinutes,
            initialLongBreak = uiState.longBreakMinutes,
            onDismiss = { viewModel.toggleSettingsDialog(false) },
            onConfirm = { f, s, l -> viewModel.setDurations(f, s, l) }
        )
    }

    // Diálogo para Contabilizar Pomodoro Incompleto
    if (uiState.showIncompleteSessionDialog) {
        val elapsedMinutes = uiState.incompleteSessionSecs / 60
        val elapsedSeconds = uiState.incompleteSessionSecs % 60
        val timeFormatted = if (elapsedMinutes > 0) "${elapsedMinutes}m ${elapsedSeconds}s" else "${elapsedSeconds}s"

        AlertDialog(
            onDismissRequest = { viewModel.cancelIncompleteDialog() },
            title = {
                Text(
                    text = "⏱️ Contabilizar Tempo Incompleto?",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Você estudou $timeFormatted neste ciclo.",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Deseja salvar e contabilizar esse tempo no histórico e estatísticas de estudo?",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = uiState.sessionNotes,
                        onValueChange = { viewModel.updateNotes(it) },
                        label = { Text("Anotações da sessão (opcional)") },
                        placeholder = { Text("Ex: Interrompido para pausa") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("incomplete_notes_input"),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.saveIncompleteSession(uiState.sessionNotes) },
                    colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                    modifier = Modifier.testTag("save_incomplete_session_button")
                ) {
                    Text("Salvar Tempo")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { viewModel.discardIncompleteSession() }) {
                        Text("Descartar", color = PomodoroRed)
                    }
                    TextButton(onClick = { viewModel.cancelIncompleteDialog() }) {
                        Text("Continuar", color = TextSecondary)
                    }
                }
            }
        )
    }
}

@Composable
fun PreSessionSetupDialog(
    topicInput: String,
    selectedSubject: SubjectEntity?,
    selectedStudyType: StudyType,
    subjects: List<SubjectEntity>,
    topics: List<TopicEntity>,
    errorMessage: String?,
    isAutoLinked: Boolean,
    onTopicChange: (String) -> Unit,
    onTopicSelectedFromList: (TopicEntity) -> Unit,
    onSubjectSelected: (SubjectEntity) -> Unit,
    onStudyTypeSelected: (StudyType) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "🎯 Configurar Sessão",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Defina o assunto e tipo antes de iniciar",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Assunto (Topic)
                Column {
                    Text(
                        text = "Qual assunto você vai estudar?",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = onTopicChange,
                        placeholder = { Text("Ex: Funções Afins, Revolução Industrial") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pre_session_topic_input"),
                        singleLine = true
                    )

                    // Sugestões rápidas de assuntos anteriores
                    if (topics.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            topics.take(6).forEach { topicItem ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SurfaceCard,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                                    modifier = Modifier.clickable { onTopicSelectedFromList(topicItem) }
                                ) {
                                    Text(
                                        text = topicItem.name,
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Matéria Vinculada (Auto-link ou Seletor)
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Matéria Vinculada",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        if (isAutoLinked) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = BreakGreen,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Vínculo Automático",
                                    fontSize = 11.sp,
                                    color = BreakGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        subjects.forEach { subject ->
                            val isSelected = selectedSubject?.id == subject.id
                            val color = try {
                                Color(android.graphics.Color.parseColor(subject.colorHex))
                            } catch (_: Exception) {
                                PomodoroRed
                            }

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) color.copy(alpha = 0.2f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) color else SurfaceCardBorder
                                ),
                                modifier = Modifier
                                    .clickable { onSubjectSelected(subject) }
                                    .testTag("subject_chip_${subject.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = subject.name,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) TextPrimary else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. Tipo de Estudo (Obrigatório)
                Column {
                    Text(
                        text = "Tipo de Estudo",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudyType.values().forEach { type ->
                            val isSelected = selectedStudyType == type
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) PomodoroRed.copy(alpha = 0.18f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) PomodoroRed else SurfaceCardBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStudyTypeSelected(type) }
                                    .testTag("study_type_${type.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = type.emoji, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = type.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) PomodoroRed else TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        color = PomodoroRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                modifier = Modifier.testTag("confirm_pre_session_button")
            ) {
                Text("Iniciar Foco")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}

@Composable
fun CircularTimerDisplay(
    timerTick: TimerTickState,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = timerTick.progress,
        animationSpec = tween(durationMillis = 500),
        label = "progress"
    )

    val minutes = timerTick.remainingSeconds / 60
    val seconds = timerTick.remainingSeconds % 60
    val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

    Box(
        modifier = modifier.size(260.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 14.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val radius = diameter / 2f
            val center = this.center

            drawCircle(
                color = SurfaceCard,
                radius = radius,
                center = center,
                style = Stroke(width = strokeWidth)
            )

            drawArc(
                color = accentColor,
                startAngle = -90f,
                sweepAngle = 360f * animatedProgress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = formattedTime,
                color = TextPrimary,
                fontSize = 52.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = when (timerTick.state) {
                    TimerState.IDLE -> "Pronto para focar"
                    TimerState.RUNNING -> "Em andamento"
                    TimerState.PAUSED -> "Pausado"
                    TimerState.COMPLETED -> "Concluído!"
                },
                color = TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun TimerSettingsDialog(
    initialFocus: Int,
    initialShortBreak: Int,
    initialLongBreak: Int,
    onDismiss: () -> Unit,
    onConfirm: (focus: Int, shortBreak: Int, longBreak: Int) -> Unit
) {
    var focusText by remember { mutableStateOf(initialFocus.toString()) }
    var shortBreakText by remember { mutableStateOf(initialShortBreak.toString()) }
    var longBreakText by remember { mutableStateOf(initialLongBreak.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Configurações de Ciclo", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 20.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Digite a duração em minutos para cada período:",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Tempo de Foco
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = focusText,
                        onValueChange = { focusText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Tempo de Foco") },
                        placeholder = { Text("Ex: 25") },
                        suffix = { Text("min", color = TextSecondary) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = null, tint = PomodoroRed)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_focus_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 25, 45, 50, 60).forEach { mins ->
                            val isSelected = focusText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) PomodoroRed.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) PomodoroRed else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { focusText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) PomodoroRed else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Pausa Curta
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = shortBreakText,
                        onValueChange = { shortBreakText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Pausa Curta") },
                        placeholder = { Text("Ex: 5") },
                        suffix = { Text("min", color = TextSecondary) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Pause, contentDescription = null, tint = BreakGreen)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_short_break_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(3, 5, 10, 15).forEach { mins ->
                            val isSelected = shortBreakText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) BreakGreen.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) BreakGreen else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { shortBreakText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) BreakGreen else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Pausa Longa
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = longBreakText,
                        onValueChange = { longBreakText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Pausa Longa") },
                        placeholder = { Text("Ex: 15") },
                        suffix = { Text("min", color = TextSecondary) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = LongBreakBlue)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setting_long_break_input"),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(10, 15, 20, 30).forEach { mins ->
                            val isSelected = longBreakText == mins.toString()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) LongBreakBlue.copy(alpha = 0.25f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) LongBreakBlue else SurfaceCardBorder
                                ),
                                modifier = Modifier.clickable { longBreakText = mins.toString() }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isSelected) LongBreakBlue else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val focus = focusText.toIntOrNull()?.coerceIn(1, 180) ?: initialFocus
                    val shortBreak = shortBreakText.toIntOrNull()?.coerceIn(1, 60) ?: initialShortBreak
                    val longBreak = longBreakText.toIntOrNull()?.coerceIn(1, 90) ?: initialLongBreak
                    onConfirm(focus, shortBreak, longBreak)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PomodoroRed),
                modifier = Modifier.testTag("save_settings_button")
            ) {
                Text("Aplicar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun StudyModeSelectorSection(
    uiState: PomodoroUiState,
    cycles: List<StudyCycleEntity>,
    cycleItems: List<CycleItemWithSubject>,
    schedules: List<ScheduleWithSubject>,
    onModeSelected: (PomodoroStudyMode) -> Unit,
    onCycleSelected: (Long) -> Unit,
    onCycleSubjectSelected: (CycleItemWithSubject) -> Unit,
    onScheduleDaySelected: (Int) -> Unit,
    onScheduleSelected: (ScheduleWithSubject) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pomodoro_study_mode_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Seletor de Modo (Ciclos vs Agendas vs Livre)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BackgroundDark, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Modo Ciclos de Estudo
                val isCycle = uiState.studyMode == PomodoroStudyMode.CYCLE
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isCycle) PomodoroRed else Color.Transparent)
                        .clickable { onModeSelected(PomodoroStudyMode.CYCLE) }
                        .padding(vertical = 8.dp)
                        .testTag("mode_cycle_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Loop,
                            contentDescription = null,
                            tint = if (isCycle) Color.White else TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Ciclos",
                            color = if (isCycle) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = if (isCycle) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }

                // Modo Agenda de Horários
                val isSchedule = uiState.studyMode == PomodoroStudyMode.SCHEDULE
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSchedule) PomodoroRed else Color.Transparent)
                        .clickable { onModeSelected(PomodoroStudyMode.SCHEDULE) }
                        .padding(vertical = 8.dp)
                        .testTag("mode_schedule_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = if (isSchedule) Color.White else TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Agendas",
                            color = if (isSchedule) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = if (isSchedule) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }

                // Modo Livre
                val isFree = uiState.studyMode == PomodoroStudyMode.FREE
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isFree) PomodoroRed else Color.Transparent)
                        .clickable { onModeSelected(PomodoroStudyMode.FREE) }
                        .padding(vertical = 8.dp)
                        .testTag("mode_free_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = if (isFree) Color.White else TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Livre",
                            color = if (isFree) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = if (isFree) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (uiState.studyMode) {
                PomodoroStudyMode.CYCLE -> {
                    if (cycles.isEmpty()) {
                        Text(
                            text = "Nenhum ciclo de estudos criado ainda. Acesse a aba Disciplinas para criar e personalizar seus ciclos.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else {
                        val activeCycleId = uiState.selectedCycleId ?: cycles.first().id
                        val activeCycle = cycles.find { it.id == activeCycleId } ?: cycles.first()

                        // Seleção de Ciclos existentes (Chips horizontais)
                        Text(
                            text = "Selecione o Ciclo de Estudos:",
                            fontSize = 11.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            cycles.forEach { cycle ->
                                val isSelected = cycle.id == activeCycle.id
                                Surface(
                                    modifier = Modifier.clickable { onCycleSelected(cycle.id) },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) PomodoroRed.copy(alpha = 0.2f) else BackgroundDark,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) PomodoroRed else SurfaceCardBorder
                                    )
                                ) {
                                    Text(
                                        text = cycle.name,
                                        color = if (isSelected) Color.White else TextSecondary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Matérias do Ciclo Ativo e Proporção
                        val items = cycleItems.filter { it.cycleId == activeCycle.id }
                        val totalMinutes = items.sumOf { it.targetMinutes }.coerceAtLeast(1)

                        if (items.isNotEmpty()) {
                            // Barra gráfica de proporção de matérias no ciclo
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${items.size} matérias no ciclo",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = "${totalMinutes} min totais",
                                        fontSize = 11.sp,
                                        color = TextMuted,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(BackgroundDark)
                                ) {
                                    items.forEach { item ->
                                        val color = try {
                                            Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                        } catch (_: Exception) {
                                            PomodoroRed
                                        }
                                        val weight = (item.targetMinutes.toFloat() / totalMinutes.toFloat()).coerceAtLeast(0.01f)
                                        Box(
                                            modifier = Modifier
                                                .weight(weight)
                                                .fillMaxHeight()
                                                .background(color)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Toque na matéria para focar agora:",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Lista de matérias com porcentagem e seleção direta
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items.forEach { item ->
                                    val isCurrentSubject = uiState.activeSubject?.id == item.subjectId
                                    val subjectColor = try {
                                        Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                    } catch (_: Exception) {
                                        PomodoroRed
                                    }
                                    val percent = ((item.targetMinutes * 100) / totalMinutes)

                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onCycleSubjectSelected(item) },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isCurrentSubject) subjectColor.copy(alpha = 0.15f) else BackgroundDark,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isCurrentSubject) subjectColor else SurfaceCardBorder
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(10.dp)
                                                        .clip(CircleShape)
                                                        .background(subjectColor)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = item.subjectName,
                                                    fontSize = 13.sp,
                                                    fontWeight = if (isCurrentSubject) FontWeight.Bold else FontWeight.Medium,
                                                    color = TextPrimary
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "${item.targetMinutes}m ($percent%)",
                                                    fontSize = 12.sp,
                                                    color = if (isCurrentSubject) subjectColor else TextMuted,
                                                    fontWeight = if (isCurrentSubject) FontWeight.Bold else FontWeight.Normal
                                                )
                                                if (isCurrentSubject) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Selecionada",
                                                        tint = subjectColor,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "Nenhuma matéria cadastrada neste ciclo.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }

                PomodoroStudyMode.SCHEDULE -> {
                    if (schedules.isEmpty()) {
                        Text(
                            text = "Nenhuma agenda criada ainda. Cadastre sua grade semanal de horários na aba Disciplinas.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else {
                        // Dias da semana
                        val days = listOf("Seg" to 1, "Ter" to 2, "Qua" to 3, "Qui" to 4, "Sex" to 5, "Sáb" to 6, "Dom" to 7)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            days.forEach { (label, dayNum) ->
                                val isSelected = uiState.selectedScheduleDayOfWeek == dayNum
                                Surface(
                                    modifier = Modifier.clickable { onScheduleDaySelected(dayNum) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) PomodoroRed.copy(alpha = 0.2f) else BackgroundDark,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) PomodoroRed else SurfaceCardBorder
                                    )
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) Color.White else TextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Horários do dia selecionado
                        val daySchedules = schedules.filter { it.dayOfWeek == uiState.selectedScheduleDayOfWeek }
                        if (daySchedules.isEmpty()) {
                            Text(
                                text = "Sem horários programados para este dia.",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                daySchedules.forEach { item ->
                                    val isSelected = uiState.selectedScheduleId == item.id && uiState.activeSubject?.id == item.subjectId
                                    val subjectColor = try {
                                        Color(android.graphics.Color.parseColor(item.subjectColorHex))
                                    } catch (_: Exception) {
                                        PomodoroRed
                                    }
                                    val timeStr = String.format(java.util.Locale.getDefault(), "%02d:%02d - %02d:%02d", item.startHour, item.startMinute, item.endHour, item.endMinute)

                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onScheduleSelected(item) },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) subjectColor.copy(alpha = 0.15f) else BackgroundDark,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelected) subjectColor else SurfaceCardBorder
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(10.dp)
                                                        .clip(CircleShape)
                                                        .background(subjectColor)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(
                                                        text = item.subjectName,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextPrimary
                                                    )
                                                    if (item.topic.isNotBlank() || item.label.isNotBlank()) {
                                                        Text(
                                                            text = item.topic.ifBlank { item.label },
                                                            fontSize = 11.sp,
                                                            color = TextSecondary
                                                        )
                                                    }
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = timeStr,
                                                    fontSize = 11.sp,
                                                    color = if (isSelected) subjectColor else TextMuted,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                if (isSelected) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Selecionado",
                                                        tint = subjectColor,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PomodoroStudyMode.FREE -> {
                    Text(
                        text = "Modo Livre: Você pode estudar qualquer tema sem amarras a ciclos ou grade. Use o botão Iniciar abaixo para definir o foco livremente.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
