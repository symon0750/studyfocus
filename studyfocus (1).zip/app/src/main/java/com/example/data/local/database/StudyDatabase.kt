package com.example.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BlockSettingsDao
import com.example.data.local.dao.BlockedAppDao
import com.example.data.local.dao.BlockedWebsiteDao
import com.example.data.local.dao.StudyCycleDao
import com.example.data.local.dao.StudyScheduleDao
import com.example.data.local.dao.StudySessionDao
import com.example.data.local.dao.SubjectDao
import com.example.data.local.dao.TopicDao
import com.example.data.local.entity.BlockSettingsEntity
import com.example.data.local.entity.BlockedAppEntity
import com.example.data.local.entity.BlockedWebsiteEntity
import com.example.data.local.entity.StudyCycleEntity
import com.example.data.local.entity.StudyCycleItemEntity
import com.example.data.local.entity.StudyScheduleEntity
import com.example.data.local.entity.StudySession
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SubjectEntity::class,
        TopicEntity::class,
        StudySession::class,
        BlockedAppEntity::class,
        BlockedWebsiteEntity::class,
        BlockSettingsEntity::class,
        StudyCycleEntity::class,
        StudyCycleItemEntity::class,
        StudyScheduleEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class StudyDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun topicDao(): TopicDao
    abstract fun blockedAppDao(): BlockedAppDao
    abstract fun blockedWebsiteDao(): BlockedWebsiteDao
    abstract fun blockSettingsDao(): BlockSettingsDao
    abstract fun studyCycleDao(): StudyCycleDao
    abstract fun studyScheduleDao(): StudyScheduleDao

    companion object {
        @Volatile
        private var INSTANCE: StudyDatabase? = null

        fun getInstance(context: Context): StudyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyDatabase::class.java,
                    "study_focus.db"
                )
                    .fallbackToDestructiveMigration()
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            populateDefaultData(context)
                        }

                        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
                            super.onDestructiveMigration(db)
                            populateDefaultData(context)
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private fun populateDefaultData(context: Context) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = getInstance(context)
                
                // Disciplinas padrão
                val subjectIds = db.subjectDao().insertSubjects(
                    listOf(
                        SubjectEntity(name = "Matemática", colorHex = "#3B82F6"),
                        SubjectEntity(name = "Português", colorHex = "#10B981"),
                        SubjectEntity(name = "Programação", colorHex = "#F59E0B"),
                        SubjectEntity(name = "História", colorHex = "#EC4899"),
                        SubjectEntity(name = "Ciências", colorHex = "#8B5CF6")
                    )
                )

                // Tópicos iniciais por matéria
                if (subjectIds.isNotEmpty()) {
                    val matId = subjectIds[0]
                    val portId = if (subjectIds.size > 1) subjectIds[1] else matId
                    val progId = if (subjectIds.size > 2) subjectIds[2] else matId

                    db.topicDao().insertTopic(TopicEntity(name = "Álgebra Linear", subjectId = matId))
                    db.topicDao().insertTopic(TopicEntity(name = "Cálculo I", subjectId = matId))
                    db.topicDao().insertTopic(TopicEntity(name = "Gramática & Sintaxe", subjectId = portId))
                    db.topicDao().insertTopic(TopicEntity(name = "Interpretação de Texto", subjectId = portId))
                    db.topicDao().insertTopic(TopicEntity(name = "Kotlin & Android", subjectId = progId))
                    db.topicDao().insertTopic(TopicEntity(name = "Estruturas de Dados", subjectId = progId))

                    // Ciclo de estudo de demonstração
                    val cycleId = db.studyCycleDao().insertCycle(
                        StudyCycleEntity(
                            name = "Ciclo Foco Geral",
                            description = "Ciclo equilibrado de matérias exatas, humanas e técnicas"
                        )
                    )
                    db.studyCycleDao().insertCycleItems(
                        listOf(
                            StudyCycleItemEntity(cycleId = cycleId, subjectId = matId, targetMinutes = 120, orderIndex = 0),
                            StudyCycleItemEntity(cycleId = cycleId, subjectId = portId, targetMinutes = 90, orderIndex = 1),
                            StudyCycleItemEntity(cycleId = cycleId, subjectId = progId, targetMinutes = 90, orderIndex = 2)
                        )
                    )

                    // Grade horária semanal de demonstração
                    db.studyScheduleDao().insertSchedule(
                        StudyScheduleEntity(
                            dayOfWeek = 1, // Segunda
                            startHour = 8, startMinute = 0,
                            endHour = 10, endMinute = 0,
                            subjectId = matId,
                            topic = "Álgebra Linear",
                            label = "Bloco Matinal"
                        )
                    )
                    db.studyScheduleDao().insertSchedule(
                        StudyScheduleEntity(
                            dayOfWeek = 1, // Segunda
                            startHour = 14, startMinute = 0,
                            endHour = 16, endMinute = 0,
                            subjectId = progId,
                            topic = "Kotlin & Android",
                            label = "Bloco da Tarde"
                        )
                    )
                    db.studyScheduleDao().insertSchedule(
                        StudyScheduleEntity(
                            dayOfWeek = 2, // Terça
                            startHour = 9, startMinute = 0,
                            endHour = 11, endMinute = 0,
                            subjectId = portId,
                            topic = "Gramática & Sintaxe",
                            label = "Português Teórico"
                        )
                    )
                }

                // Apps de distração conhecidos pré-cadastrados
                db.blockedAppDao().insertAll(
                    listOf(
                        BlockedAppEntity(packageName = "com.instagram.android", appName = "Instagram", isBlocked = true, category = "Redes Sociais"),
                        BlockedAppEntity(packageName = "com.zhiliaoapp.musically", appName = "TikTok", isBlocked = true, category = "Redes Sociais"),
                        BlockedAppEntity(packageName = "com.google.android.youtube", appName = "YouTube", isBlocked = true, category = "Vídeo"),
                        BlockedAppEntity(packageName = "com.twitter.android", appName = "X / Twitter", isBlocked = true, category = "Redes Sociais"),
                        BlockedAppEntity(packageName = "com.facebook.katana", appName = "Facebook", isBlocked = true, category = "Redes Sociais"),
                        BlockedAppEntity(packageName = "com.reddit.frontpage", appName = "Reddit", isBlocked = true, category = "Fóruns"),
                        BlockedAppEntity(packageName = "com.netflix.mediaclient", appName = "Netflix", isBlocked = true, category = "Streaming"),
                        BlockedAppEntity(packageName = "tv.twitch.android.app", appName = "Twitch", isBlocked = true, category = "Streaming")
                    )
                )

                // Sites de distração comuns pré-cadastrados
                db.blockedWebsiteDao().insertAll(
                    listOf(
                        BlockedWebsiteEntity(domain = "instagram.com", isBlocked = true, category = "Redes Sociais"),
                        BlockedWebsiteEntity(domain = "tiktok.com", isBlocked = true, category = "Redes Sociais"),
                        BlockedWebsiteEntity(domain = "twitter.com", isBlocked = true, category = "Redes Sociais"),
                        BlockedWebsiteEntity(domain = "x.com", isBlocked = true, category = "Redes Sociais"),
                        BlockedWebsiteEntity(domain = "facebook.com", isBlocked = true, category = "Redes Sociais"),
                        BlockedWebsiteEntity(domain = "youtube.com", isBlocked = true, category = "Vídeo"),
                        BlockedWebsiteEntity(domain = "reddit.com", isBlocked = true, category = "Fóruns"),
                        BlockedWebsiteEntity(domain = "netflix.com", isBlocked = true, category = "Streaming"),
                        BlockedWebsiteEntity(domain = "twitch.tv", isBlocked = true, category = "Streaming")
                    )
                )

                // Configurações padrão
                db.blockSettingsDao().saveSettings(BlockSettingsEntity())
            }
        }
    }
}
