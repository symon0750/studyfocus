package com.example

import com.example.domain.model.PomodoroPhase
import com.example.domain.model.TimerState
import com.example.service.PomodoroTimerManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PomodoroTimerManagerTest {

    private lateinit var testScope: TestScope
    private lateinit var timerManager: PomodoroTimerManager

    @Before
    fun setup() {
        val testDispatcher = StandardTestDispatcher()
        testScope = TestScope(testDispatcher)
        timerManager = PomodoroTimerManager(scope = testScope)
    }

    @Test
    fun testInitialState() {
        val state = timerManager.timerState.value
        assertEquals(TimerState.IDLE, state.state)
        assertEquals(PomodoroPhase.FOCUS, state.phase)
        assertEquals(25 * 60, state.remainingSeconds)
        assertEquals(1, state.currentCycle)
    }

    @Test
    fun testStartAndPause() {
        timerManager.startOrResume(targetMinutes = 25)
        var state = timerManager.timerState.value
        assertEquals(TimerState.RUNNING, state.state)
        assertEquals(25 * 60, state.totalSeconds)

        timerManager.pause()
        state = timerManager.timerState.value
        assertEquals(TimerState.PAUSED, state.state)

        timerManager.resume()
        state = timerManager.timerState.value
        assertEquals(TimerState.RUNNING, state.state)

        timerManager.stopAndReset()
        state = timerManager.timerState.value
        assertEquals(TimerState.IDLE, state.state)
        assertEquals(25 * 60, state.remainingSeconds)
    }

    @Test
    fun testPhaseTransitionsAndCycles() {
        // Ciclo 1 Foco -> Pausa Curta
        timerManager.skipToNextPhase()
        var state = timerManager.timerState.value
        assertEquals(PomodoroPhase.SHORT_BREAK, state.phase)
        assertEquals(1, state.currentCycle)
        assertEquals(5 * 60, state.remainingSeconds)

        // Pausa Curta -> Ciclo 2 Foco
        timerManager.skipToNextPhase()
        state = timerManager.timerState.value
        assertEquals(PomodoroPhase.FOCUS, state.phase)
        assertEquals(2, state.currentCycle)

        // Avança até ciclo 4
        timerManager.skipToNextPhase() // Pausa curta ciclo 2
        timerManager.skipToNextPhase() // Ciclo 3 foco
        timerManager.skipToNextPhase() // Pausa curta ciclo 3
        timerManager.skipToNextPhase() // Ciclo 4 foco

        state = timerManager.timerState.value
        assertEquals(PomodoroPhase.FOCUS, state.phase)
        assertEquals(4, state.currentCycle)

        // Do ciclo 4 de foco deve ir para Pausa Longa!
        timerManager.skipToNextPhase()
        state = timerManager.timerState.value
        assertEquals(PomodoroPhase.LONG_BREAK, state.phase)
        assertEquals(15 * 60, state.remainingSeconds)
    }
}
