package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.database.StudyDatabase
import com.example.data.local.entity.StudySession
import com.example.data.local.entity.SubjectEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StudySessionDaoTest {

    private lateinit var database: StudyDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, StudyDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        database.close()
    }

    @Test
    fun testInsertAndRetrieveSubject() = runBlocking {
        val subjectDao = database.subjectDao()
        val subjectId = subjectDao.insertSubject(
            SubjectEntity(name = "Matemática", colorHex = "#3B82F6")
        )
        assertTrue(subjectId > 0)

        val retrieved = subjectDao.getSubjectById(subjectId)
        assertNotNull(retrieved)
        assertEquals("Matemática", retrieved?.name)
        assertEquals("#3B82F6", retrieved?.colorHex)
    }

    @Test
    fun testInsertSessionAndAggregation() = runBlocking {
        val subjectDao = database.subjectDao()
        val sessionDao = database.studySessionDao()

        val subjectId = subjectDao.insertSubject(
            SubjectEntity(name = "Programação", colorHex = "#F59E0B")
        )

        val now = System.currentTimeMillis()

        // Insere 2 sessões concluídas de 25 minutos (1500 segundos cada)
        sessionDao.insertSession(
            StudySession(
                subjectId = subjectId,
                category = "FOCUS",
                totalDuration = 1500L,
                startTime = now - 5000000,
                endTime = now - 3500000,
                completed = true,
                notes = "Estudo de Kotlin"
            )
        )

        sessionDao.insertSession(
            StudySession(
                subjectId = subjectId,
                category = "FOCUS",
                totalDuration = 1500L,
                startTime = now - 2000000,
                endTime = now - 500000,
                completed = true,
                notes = "Coroutines & Room"
            )
        )

        val allTimeStats = sessionDao.getAllTimeStats().first()
        assertEquals(3000L, allTimeStats.totalSeconds)
        assertEquals(2, allTimeStats.totalSessions)
        assertEquals(2, allTimeStats.completedSessions)
    }

    @Test
    fun testScaleRegression_insertHundredsOfSessions() = runBlocking {
        val subjectDao = database.subjectDao()
        val sessionDao = database.studySessionDao()

        val sub1 = subjectDao.insertSubject(SubjectEntity(name = "História", colorHex = "#EC4899"))
        val sub2 = subjectDao.insertSubject(SubjectEntity(name = "Biologia", colorHex = "#10B981"))

        val baseTime = 1700000000000L

        // Insere 200 sessões em lote simulando meses de histórico contínuo
        for (i in 1..200) {
            val subId = if (i % 2 == 0) sub1 else sub2
            sessionDao.insertSession(
                StudySession(
                    subjectId = subId,
                    category = "FOCUS",
                    totalDuration = 1500L,
                    startTime = baseTime + (i * 3600000L),
                    endTime = baseTime + (i * 3600000L) + 1500000L,
                    completed = true,
                    notes = "Sessão $i"
                )
            )
        }

        val count = sessionDao.getCount()
        assertEquals(200, count)

        // As agregações via índice B-Tree devem calcular instantaneamente e com precisão
        val allTime = sessionDao.getAllTimeStats().first()
        assertEquals(200 * 1500L, allTime.totalSeconds)
        assertEquals(200, allTime.totalSessions)

        val pagedList = sessionDao.getRecentSessionsWithSubjectPaged(limit = 10, offset = 0).first()
        assertEquals(10, pagedList.size)
    }

    @Test
    fun testCrudMethods() = runBlocking {
        val sessionDao = database.studySessionDao()
        val now = System.currentTimeMillis()

        // 1. Insert
        val session1 = StudySession(
            category = "FOCUS",
            totalDuration = 1800L,
            startTime = now - 3600000,
            endTime = now - 1800000,
            completed = true,
            notes = "Foco em Cálculo"
        )
        val session2 = StudySession(
            category = "SHORT_BREAK",
            totalDuration = 300L,
            startTime = now - 1800000,
            endTime = now - 1500000,
            completed = true,
            notes = "Pausa para café"
        )

        val id1 = sessionDao.insert(session1)
        val id2 = sessionDao.insert(session2)
        assertTrue(id1 > 0)
        assertTrue(id2 > 0)

        // 2. Query All
        val all = sessionDao.getAllSessions().first()
        assertEquals(2, all.size)

        // 3. Query by Category
        val focusOnly = sessionDao.getSessionsByCategory("FOCUS").first()
        assertEquals(1, focusOnly.size)
        assertEquals("FOCUS", focusOnly.first().category)

        val breaksOnly = sessionDao.getSessionsByCategory("SHORT_BREAK").first()
        assertEquals(1, breaksOnly.size)
        assertEquals("SHORT_BREAK", breaksOnly.first().category)

        // 4. Delete
        sessionDao.delete(all.first())
        val afterDelete = sessionDao.getAllSessions().first()
        assertEquals(1, afterDelete.size)
    }

    @Test
    fun testTopicAndStudyTypeAssociation() = runBlocking {
        val subjectDao = database.subjectDao()
        val topicDao = database.topicDao()
        val sessionDao = database.studySessionDao()

        val mathId = subjectDao.insertSubject(
            SubjectEntity(name = "Matemática", colorHex = "#3B82F6")
        )

        // 1. Inserir tópico vinculado à matéria
        topicDao.insertTopic(
            com.example.data.local.entity.TopicEntity(
                name = "Equações de 2º Grau",
                subjectId = mathId
            )
        )

        // 2. Busca automática de matéria pelo nome do tópico
        val foundTopic = topicDao.findByName("equações de 2º grau") // case-insensitive
        assertNotNull(foundTopic)
        assertEquals(mathId, foundTopic?.subjectId)

        // 3. Inserir sessão com topic e studyType
        val sessionId = sessionDao.insert(
            StudySession(
                subjectId = mathId,
                topic = "Equações de 2º Grau",
                studyType = "EXERCISES",
                category = "FOCUS",
                totalDuration = 2700L,
                startTime = System.currentTimeMillis() - 2700000L,
                endTime = System.currentTimeMillis(),
                completed = true,
                notes = "Lista de 15 exercícios"
            )
        )
        assertTrue(sessionId > 0)

        // 4. Recupera com junção de matéria
        val recent = sessionDao.getRecentSessionsWithSubjectPaged(limit = 1, offset = 0).first()
        assertEquals(1, recent.size)
        assertEquals("Equações de 2º Grau", recent.first().topic)
        assertEquals("EXERCISES", recent.first().studyType)
        assertEquals("Matemática", recent.first().subjectName)
    }

    @Test
    fun testIncompleteSessionRecordedAndAggregated() = runBlocking {
        val subjectDao = database.subjectDao()
        val sessionDao = database.studySessionDao()

        val subjectId = subjectDao.insertSubject(
            SubjectEntity(name = "Física", colorHex = "#10B981")
        )

        val now = System.currentTimeMillis()
        // Sessão incompleta: o usuário estudou 12 minutos (720 segundos) de um pomodoro de 25 minutos
        sessionDao.insertSession(
            StudySession(
                subjectId = subjectId,
                topic = "Cinemática",
                studyType = "VIDEO",
                category = "FOCUS",
                totalDuration = 720L,
                startTime = now - 720000L,
                endTime = now,
                completed = false,
                notes = "Ciclo finalizado antecipadamente"
            )
        )

        // Verifica que o tempo incompleto é contabilizado nas estatísticas
        val stats = sessionDao.getAllTimeStats().first()
        assertEquals(720L, stats.totalSeconds)
        assertEquals(1, stats.totalSessions)
        assertEquals(0, stats.completedSessions) // Incompleta, mas tempo contabilizado!

        // Verifica que o dia de estudo foi registrado para fins de streak
        val distinctDays = sessionDao.getDistinctStudyDays().first()
        assertEquals(1, distinctDays.size)

        // Verifica no histórico
        val paged = sessionDao.getRecentSessionsWithSubjectPaged(limit = 5, offset = 0).first()
        assertEquals(1, paged.size)
        assertEquals(false, paged.first().completed)
        assertEquals(720, paged.first().actualDurationSeconds)
        assertEquals("Cinemática", paged.first().topic)
    }
}
