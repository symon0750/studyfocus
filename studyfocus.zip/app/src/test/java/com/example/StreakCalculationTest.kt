package com.example

import com.example.data.repository.StudyRepository
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class StreakCalculationTest {

    @Test
    fun testEmptyDays() {
        val streak = StudyRepository.calculateStreak(emptyList())
        assertEquals(0, streak)
    }

    @Test
    fun testActiveStreakTodayAndYesterday() {
        val today = LocalDate.now().toString()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val dayBefore = LocalDate.now().minusDays(2).toString()

        val streak = StudyRepository.calculateStreak(listOf(today, yesterday, dayBefore))
        assertEquals(3, streak)
    }

    @Test
    fun testBrokenStreak() {
        val threeDaysAgo = LocalDate.now().minusDays(3).toString()
        val fourDaysAgo = LocalDate.now().minusDays(4).toString()

        val streak = StudyRepository.calculateStreak(listOf(threeDaysAgo, fourDaysAgo))
        assertEquals(0, streak)
    }
}
