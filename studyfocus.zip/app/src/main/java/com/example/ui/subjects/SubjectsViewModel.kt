package com.example.ui.subjects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.SubjectEntity
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SubjectsUiState(
    val showAddEditDialog: Boolean = false,
    val editingSubject: SubjectEntity? = null,
    val nameInput: String = "",
    val selectedColorHex: String = "#3B82F6",
    val errorMessage: String? = null
)

class SubjectsViewModel(
    private val repository: StudyRepository
) : ViewModel() {

    val subjects: StateFlow<List<SubjectEntity>> = repository.allSubjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow(SubjectsUiState())
    val uiState: StateFlow<SubjectsUiState> = _uiState.asStateFlow()

    val availableColors = listOf(
        "#3B82F6", // Blue
        "#10B981", // Emerald
        "#F59E0B", // Amber
        "#EF4444", // Red
        "#8B5CF6", // Purple
        "#EC4899", // Pink
        "#06B6D4", // Cyan
        "#14B8A6"  // Teal
    )

    fun openAddDialog() {
        _uiState.update {
            it.copy(
                showAddEditDialog = true,
                editingSubject = null,
                nameInput = "",
                selectedColorHex = availableColors.first(),
                errorMessage = null
            )
        }
    }

    fun openEditDialog(subject: SubjectEntity) {
        _uiState.update {
            it.copy(
                showAddEditDialog = true,
                editingSubject = subject,
                nameInput = subject.name,
                selectedColorHex = subject.colorHex,
                errorMessage = null
            )
        }
    }

    fun closeDialog() {
        _uiState.update { it.copy(showAddEditDialog = false, errorMessage = null) }
    }

    fun onNameChange(name: String) {
        _uiState.update { it.copy(nameInput = name, errorMessage = null) }
    }

    fun onColorSelect(colorHex: String) {
        _uiState.update { it.copy(selectedColorHex = colorHex) }
    }

    fun saveSubject() {
        val name = _uiState.value.nameInput.trim()
        if (name.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "O nome da disciplina não pode ficar vazio") }
            return
        }

        val color = _uiState.value.selectedColorHex
        val currentEdit = _uiState.value.editingSubject

        viewModelScope.launch {
            if (currentEdit != null) {
                repository.updateSubject(currentEdit.copy(name = name, colorHex = color))
            } else {
                repository.createSubject(name = name, colorHex = color)
            }
            closeDialog()
        }
    }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch {
            repository.deleteSubject(subject)
        }
    }
}

class SubjectsViewModelFactory(
    private val repository: StudyRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SubjectsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SubjectsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
