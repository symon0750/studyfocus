package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Timer
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppDestination(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    POMODORO("pomodoro", "Pomodoro", Icons.Default.Timer),
    HISTORY("history", "Histórico", Icons.Default.History),
    STATS("stats", "Estatísticas", Icons.Default.BarChart),
    SUBJECTS("subjects", "Disciplinas", Icons.Default.Book)
}
