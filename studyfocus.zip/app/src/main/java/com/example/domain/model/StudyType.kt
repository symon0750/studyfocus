package com.example.domain.model

enum class StudyType(val id: String, val label: String, val emoji: String) {
    READING("READING", "Leitura", "📖"),
    EXERCISES("EXERCISES", "Questões", "📝"),
    VIDEO("VIDEO", "Vídeo", "🎥"),
    REVIEW("REVIEW", "Revisão", "🔄");

    companion object {
        fun fromId(id: String?): StudyType {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: READING
        }
    }
}
