package com.example.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.StudySessionDao
import com.example.data.local.dao.SubjectDao
import com.example.data.local.dao.TopicDao
import com.example.data.local.entity.StudySession
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [SubjectEntity::class, TopicEntity::class, StudySession::class],
    version = 3,
    exportSchema = false
)
abstract class StudyDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun topicDao(): TopicDao

    companion object {
        @Volatile
        private var INSTANCE: StudyDatabase? = null

        fun getInstance(context: Context): StudyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyDatabase::class.java,
                    "study_focus.db"
                )
                    .fallbackToDestructiveMigration()
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            populateDefaultSubjects(context)
                        }

                        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
                            super.onDestructiveMigration(db)
                            populateDefaultSubjects(context)
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private fun populateDefaultSubjects(context: Context) {
            CoroutineScope(Dispatchers.IO).launch {
                val dao = getInstance(context).subjectDao()
                dao.insertSubjects(
                    listOf(
                        SubjectEntity(name = "Matemática", colorHex = "#3B82F6"),
                        SubjectEntity(name = "Português", colorHex = "#10B981"),
                        SubjectEntity(name = "Programação", colorHex = "#F59E0B"),
                        SubjectEntity(name = "História", colorHex = "#EC4899"),
                        SubjectEntity(name = "Ciências", colorHex = "#8B5CF6")
                    )
                )
            }
        }
    }
}
