package com.example.data.repository

import com.example.data.local.dao.DailySummaryDto
import com.example.data.local.dao.SessionWithSubject
import com.example.data.local.dao.StudySessionDao
import com.example.data.local.dao.SubjectDao
import com.example.data.local.dao.SubjectStatDto
import com.example.data.local.dao.TopicDao
import com.example.data.local.entity.StudySession
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class StudyRepository(
    private val subjectDao: SubjectDao,
    private val studySessionDao: StudySessionDao,
    private val topicDao: TopicDao
) {
    // Disciplinas
    val allSubjects: Flow<List<SubjectEntity>> = subjectDao.getAllSubjects()

    suspend fun getSubjectById(id: Long): SubjectEntity? = withContext(Dispatchers.IO) {
        subjectDao.getSubjectById(id)
    }

    suspend fun createSubject(name: String, colorHex: String, iconName: String = "book"): Long =
        withContext(Dispatchers.IO) {
            subjectDao.insertSubject(
                SubjectEntity(
                    name = name.trim(),
                    colorHex = colorHex,
                    iconName = iconName
                )
            )
        }

    suspend fun updateSubject(subject: SubjectEntity) = withContext(Dispatchers.IO) {
        subjectDao.updateSubject(subject)
    }

    suspend fun deleteSubject(subject: SubjectEntity) = withContext(Dispatchers.IO) {
        subjectDao.deleteSubject(subject)
    }

    // Assuntos / Tópicos (Vínculo com Matéria)
    val allTopics: Flow<List<TopicEntity>> = topicDao.getAllTopics()

    suspend fun findTopicByName(name: String): TopicEntity? = withContext(Dispatchers.IO) {
        topicDao.findByName(name.trim())
    }

    suspend fun getSubjectForTopic(topicName: String): SubjectEntity? = withContext(Dispatchers.IO) {
        val topic = topicDao.findByName(topicName.trim())
        if (topic != null) {
            subjectDao.getSubjectById(topic.subjectId)
        } else {
            null
        }
    }

    suspend fun associateTopicWithSubject(topicName: String, subjectId: Long) = withContext(Dispatchers.IO) {
        val trimmed = topicName.trim()
        if (trimmed.isEmpty()) return@withContext
        val existing = topicDao.findByName(trimmed)
        if (existing != null) {
            topicDao.updateTopic(existing.copy(subjectId = subjectId, lastUsedEpochMs = System.currentTimeMillis()))
        } else {
            topicDao.insertTopic(TopicEntity(name = trimmed, subjectId = subjectId))
        }
    }

    // Sessões de Estudo
    suspend fun recordSession(
        subjectId: Long?,
        topic: String = "",
        studyType: String = "READING",
        phaseType: String = "FOCUS",
        targetDurationSeconds: Int,
        actualDurationSeconds: Int,
        startTimeEpochMs: Long,
        endTimeEpochMs: Long,
        completed: Boolean,
        notes: String = ""
    ): Long = withContext(Dispatchers.IO) {
        // Se houver assunto e matéria, atualiza o mapeamento automático
        val trimmedTopic = topic.trim()
        if (trimmedTopic.isNotEmpty() && subjectId != null) {
            val existing = topicDao.findByName(trimmedTopic)
            if (existing != null) {
                topicDao.updateTopic(existing.copy(subjectId = subjectId, lastUsedEpochMs = System.currentTimeMillis()))
            } else {
                topicDao.insertTopic(TopicEntity(name = trimmedTopic, subjectId = subjectId))
            }
        }

        studySessionDao.insertSession(
            StudySession(
                subjectId = subjectId,
                topic = trimmedTopic,
                studyType = studyType,
                category = phaseType,
                totalDuration = actualDurationSeconds.toLong(),
                startTime = startTimeEpochMs,
                endTime = endTimeEpochMs,
                completed = completed,
                notes = notes.trim()
            )
        )
    }

    suspend fun recordManualSession(
        subjectId: Long?,
        topic: String,
        studyType: String,
        durationMinutes: Int,
        startTimeEpochMs: Long,
        notes: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val durationSeconds = durationMinutes * 60
        val endTimeEpochMs = startTimeEpochMs + (durationSeconds * 1000L)
        recordSession(
            subjectId = subjectId,
            topic = topic,
            studyType = studyType,
            phaseType = "FOCUS",
            targetDurationSeconds = durationSeconds,
            actualDurationSeconds = durationSeconds,
            startTimeEpochMs = startTimeEpochMs,
            endTimeEpochMs = endTimeEpochMs,
            completed = true,
            notes = notes
        )
    }

    suspend fun deleteSession(id: Long) = withContext(Dispatchers.IO) {
        studySessionDao.deleteSessionById(id)
    }

    fun getRecentSessions(limit: Int = 100, offset: Int = 0): Flow<List<SessionWithSubject>> {
        return studySessionDao.getRecentSessionsWithSubjectPaged(limit, offset)
    }

    fun getTodaySummary(): Flow<DailySummaryDto> {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val startOfDay = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val endOfDay = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return studySessionDao.getDailyAggregation(startOfDay, endOfDay)
    }

    fun getAllTimeStats(): Flow<DailySummaryDto> {
        return studySessionDao.getAllTimeStats()
    }

    fun getSubjectStats(daysLookback: Int = 30): Flow<List<SubjectStatDto>> {
        val zone = ZoneId.systemDefault()
        val startOfPeriod = LocalDate.now().minusDays(daysLookback.toLong())
            .atStartOfDay(zone).toInstant().toEpochMilli()
        val nowEpoch = System.currentTimeMillis() + 86400000L
        return studySessionDao.getSubjectStats(startOfPeriod, nowEpoch)
    }

    fun getCurrentStreakDays(): Flow<Int> {
        return studySessionDao.getDistinctStudyDays().map { studyDays ->
            calculateStreak(studyDays)
        }
    }

    companion object {
        fun calculateStreak(studyDays: List<String>): Int {
            if (studyDays.isEmpty()) return 0
            val today = LocalDate.now()
            val parsedDays = studyDays.mapNotNull {
                try {
                    LocalDate.parse(it)
                } catch (e: Exception) {
                    null
                }
            }.distinct().sortedDescending()

            if (parsedDays.isEmpty()) return 0

            val mostRecent = parsedDays.first()
            val diffFromToday = ChronoUnit.DAYS.between(mostRecent, today)

            if (diffFromToday > 1) return 0

            var streak = 1
            for (i in 0 until parsedDays.size - 1) {
                val current = parsedDays[i]
                val prev = parsedDays[i + 1]
                if (ChronoUnit.DAYS.between(prev, current) == 1L) {
                    streak++
                } else {
                    break
                }
            }
            return streak
        }
    }
}
